﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleConvertionsCodingTest
{
    public class Convertion
    {
        public static string Calculate(Model model)
        {
            string retValue;

            //example: input 2km, number of m=?
            if (model.FromTo == FromTo.To)
            {
                model.Result = model.ValueToCalculate * 1.0M / model.Current.Factor;
                retValue = string.Format("{0} [{1}] = {2:0.000} [{3}]", model.ValueToCalculate, model.Current.Unit, model.Result, model.baseUnit);
            }
            else//example: input 2m, number of km=?
            {
                model.Result = model.ValueToCalculate * model.Current.Factor;
                retValue = string.Format("{0} [{1}] = {2:0.000} [{3}]", model.ValueToCalculate, model.baseUnit, model.Result, model.Current.Unit);
            }

            return retValue;
        }
    }
}
