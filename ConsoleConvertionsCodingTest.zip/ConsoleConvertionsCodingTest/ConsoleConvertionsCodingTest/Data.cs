﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;

namespace ConsoleConvertionsCodingTest
{
    public class Data
    {
        private string m_path;

        public Data(string path)
        {
            m_path = path;
        }

        public List<DataUnit> Read(CultureInfo cInfo)
        {
            var retList = new List<DataUnit>();

            try
            {
                using (StreamReader reader = new StreamReader(m_path))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] tabStr = line.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                        var du = new DataUnit()
                        {
                            Type = tabStr[0],
                            Unit = tabStr[1],
                            Factor = decimal.Parse(tabStr[2], cInfo)
                        };
                        retList.Add(du);
                    }
                }
            }//try
            catch (Exception e)
            {
                Console.WriteLine("Can not access the file or data error. Details:");
                Console.WriteLine(e.Message);
                throw new ArgumentException();
            }
            return retList;
        }
    }
}
