﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace ConsoleConvertionsCodingTest
{
    public class Model
    {
        private string m_path;
        private CultureInfo m_cInfo;
        public List<DataUnit> dataList;

        public List<string> OperationsType { get; set; }

        public List<string> OperationsUnit { get; set; }

        public DataUnit Current { get; set; }

        public FromTo FromTo { get; set; }

        public decimal ValueToCalculate { get; set; }

        public string baseUnit { get; set; }

        public decimal Result { get; set; }

        public Model(string path,CultureInfo cInfo)
        {
            m_path = path;
            m_cInfo = cInfo;

            var data = new Data(m_path);
            dataList = data.Read(m_cInfo);

            OperationsType = new List<string>();

            OperationsType =
                dataList.GroupBy(dataUnit => dataUnit.Type).Select(g => g.Key).ToList();

            OperationsUnit = new List<string>();

            Current = new DataUnit();
        }

    }
}
