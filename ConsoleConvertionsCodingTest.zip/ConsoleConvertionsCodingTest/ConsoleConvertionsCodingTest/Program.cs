﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace ConsoleConvertionsCodingTest
{
    class Program
    {
        static Model model;

        static void Main(string[] args)
        {
            var CultureInfo = new CultureInfo("en-GB");
            Thread.CurrentThread.CurrentUICulture = CultureInfo;
            Thread.CurrentThread.CurrentCulture = CultureInfo;

            int quit;

            model = new Model(@"..\..\Units.txt", new CultureInfo("en-GB"));

            quit = Menu1(); if (quit == 1) return;
            quit = Menu2(); if (quit == 1) return;
            quit = Menu3(); if (quit == 1) return;
            Menu4();

            var res = Convertion.Calculate(model);

            Console.WriteLine("{0}", res);
            Console.ReadLine();
            
        }

        static int Menu1()
        {
            Console.WriteLine("Input integer value indicating the type of operation: 1-{0}. Press 0 to exit program", model.OperationsType.Count);
            for (int i = 0; i < model.OperationsType.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, model.OperationsType[i]);
            }
            Console.WriteLine("Your choice: ");
            var resStr = Console.ReadLine();
            int resInt;

            if (!int.TryParse(resStr, out resInt))
                throw new ArgumentException("Invalid input parameter");

            if (resInt == 0) return 1;

            model.Current.Type = model.OperationsType.Take(resInt).Last();

            return 0;
        }



        static int Menu2()
        {
             model.baseUnit = model.dataList.Where(du=>du.Type.Equals(model.Current.Type)&&du.Factor==1)
                .First().Unit;

             Console.WriteLine("Convertion from base type {0} or to {0}? 0 for exit.", model.baseUnit);
             Console.WriteLine("1. From {0}", model.baseUnit);
             Console.WriteLine("2. To   {0}", model.baseUnit);

            Console.WriteLine("Your choice: ");
            var resStr = Console.ReadLine();
            int resInt;

            if (!int.TryParse(resStr, out resInt))
                throw new ArgumentException("Invalid input parameter");

            if (resInt == 0) return 1;

            if (resInt == 1) model.FromTo = FromTo.From;
            else
                model.FromTo = FromTo.To;

            return 0;
        }


        static int Menu3()
        {
            model.OperationsUnit =
                model.dataList.Where(dataUnit => dataUnit.Type.Equals(model.Current.Type))
                .Select(dataUnit => dataUnit.Unit).ToList();

            Console.WriteLine("Choose units 1-{0}. Press 0 to exit program", model.OperationsUnit.Count);
            for (int i = 0; i < model.OperationsUnit.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, model.OperationsUnit[i]);
            }
            Console.WriteLine("Your choice: ");
            var resStr = Console.ReadLine();
            int resInt;

            if (!int.TryParse(resStr, out resInt))
                throw new ArgumentException("Invalid input parameter");

            if (resInt == 0) return 1;

            model.Current.Unit = model.OperationsUnit.Take(resInt).Last();
            model.Current.Factor = model.dataList
                .Where(du => du.Type.Equals(model.Current.Type) && du.Unit.Equals(model.Current.Unit))
                .Select(du => du.Factor).First();

            return 0;
        }



        static int Menu4()
        {
            Console.WriteLine("Input numeric value.");
            var resStr = Console.ReadLine();
            decimal resDec;

            if (!decimal.TryParse(resStr, out resDec))
                throw new ArgumentException("Invalid input parameter");

            model.ValueToCalculate=resDec;

            return 0;
        }





    }
}
