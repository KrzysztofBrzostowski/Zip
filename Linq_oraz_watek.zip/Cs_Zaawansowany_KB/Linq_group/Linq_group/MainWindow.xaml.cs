﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Linq_group
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        string[] words = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese" }; 
      
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            var list = new List<string> { "Foo1", "Foo2", "Foo3", "Foo2", "Foo3", "Foo3", "Foo1", "Foo1" };

            var grouped = words
                .GroupBy(w => w[0])
                .Select(g => new { Word = g.Key, words = g });
            //g jest kolekcja "grup" o tym samym kluczu

            foreach (var item in grouped)
            {
                textBox1.Text += item.Word + " " + string.Join(",",item.words) +Environment.NewLine;
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            var x = words.Single(z => { return (z == "Ala"); });//wyjatek bo nie znalazl "Ala"
            MessageBox.Show(x.ToString());
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            var x = words.SingleOrDefault (z => { return (z == "Ala"); });
            if (null != x)
            {
                MessageBox.Show(x.ToString());
            }
        }
    }
}
