﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Threading;

namespace WatkiSynchronizacja
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bw_RunWorkerCompleted);
            bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            bw.ProgressChanged += new ProgressChangedEventHandler(bw_ProgressChanged);
            bw.WorkerReportsProgress = true;
        }

        void bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //throw new NotImplementedException();
            //textBox1.Text += 

            progressBar1.Value += 1;
            //e.UserState <-- tu przesylamy efekty obleczen
        }

        void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                Thread.Sleep(500);
                bw.ReportProgress(1);
            }
        }
        

        BackgroundWorker bw = new BackgroundWorker();

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            progressBar1.Maximum = 10;
            bw.RunWorkerAsync();//bw_DoWork
            
        }



        void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {//to jest uruchmiane jako zdarzenie, ze watek sie skonczyl
            textBox1.Text = DateTime.Now.ToString();            
        }
    }
}
