﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PracaDomowa_TestEvent_v01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<Zdarzenie> ListaZeZdarzeniem = new List<Zdarzenie>();
        List<Zdarzenie> ListaZeZdarzeniem1 = new List<Zdarzenie>();

        Zdarzenie z1 = new Zdarzenie();
        Zdarzenie z2 = new Zdarzenie();


        public void z1_Zdarz2() { MessageBox.Show("Zarzenie 1"); }
        public void z2_Zdarz2() { MessageBox.Show("Zarzenie 2"); }


        public MainWindow()
        {
            InitializeComponent();

            z1.Zdarz2 +=new Action(z1_Zdarz2);
            z1.id = 0;
            z1.nazwa = "Zdarzenie0";
            
            
            z2.Zdarz2 += new Action(z2_Zdarz2);
            z2.id = 1;
            z2.nazwa = "Zdarzenie1";

            ListaZeZdarzeniem.Add(z1);
            ListaZeZdarzeniem.Add(z2);


  //          comboBox1.DisplayMemberPath = "nazwa";
  //          comboBox1.ItemsSource = ListaZeZdarzeniem;

            /* To jest poprawne
            for (int i = 0; i<5; i++)
            {
                Zdarzenie x = new Zdarzenie();
                x.id = i;
                x.nazwa = i.ToString() + " ";
                x.Zdarz2 += new Action( () => { MessageBox.Show(x.nazwa);} );

                ListaZeZdarzeniem1.Add(x);
            }
             Koniec poprawnego */


            for (int i = 0; i < 5; i++)
            {
                Zdarzenie x = new Zdarzenie() { id = i, nazwa = i.ToString() };
                x.Zdarz2 += new Action(() => { MessageBox.Show(x.nazwa); });

                ListaZeZdarzeniem1.Add(x);
            }

            comboBox1.DisplayMemberPath = "nazwa";
            comboBox1.ItemsSource = ListaZeZdarzeniem1;


/*

            for (int i = 0; i < 5; i++)
            {

                ListaZeZdarzeniem.Add(
                    new Zdarzenie
                    {
                        id = i,
                        nazwa = "Zdarzenie nr " + i,

                        Zdarz2 += new Action
                            (
                            () => 
                            {

                                MessageBox.Show(nazwa);
                            
                            }

                            )
                    }//zdarzenie
                    );
            }//for

            */


/*

EventTest test = new EventTest();
test.PodniesionoAlarm += new EventHandler(test_PodniesionoAlarm);
test.PodniesionoAlarm2 += new Action(test_PodniesionoAlarm2);


    * */

        }

        private void Button01Clicked(object sender, RoutedEventArgs e)
        {

            if (comboBox1.SelectedIndex >= 0)
            {
                ListaZeZdarzeniem1[comboBox1.SelectedIndex].ProcUruchomZdarzenie();
            }

        }
    }
}
