# Read_XY_Coordinates_From_Image_Ver0.1

Application does read (x,y) coordinates from *.BMP file.

WARNING!!!

You must be sure, the Image File contain ONLY BLACK POINTS.

Author
