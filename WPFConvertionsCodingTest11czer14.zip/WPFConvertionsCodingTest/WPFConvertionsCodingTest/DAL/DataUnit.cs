﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFConvertionsCodingTest
{
    public class DataUnit
    {
        public String Type { get; set; }
        public String Unit { get; set; }
        public decimal Factor { get; set; }
    }

    public enum FromTo { From, To }

}
