﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleConvertionsCodingTest
{
    public class DataUnit
    {
        public string Type { get; set; }
        public string Unit { get; set; }
        public decimal Factor { get; set; }
    }

    public enum FromTo { From, To }

}
