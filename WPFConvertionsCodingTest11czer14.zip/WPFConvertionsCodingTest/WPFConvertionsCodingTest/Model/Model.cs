﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace WPFConvertionsCodingTest
{
    public class Model : INotifyPropertyChanged
    {
        private string m_path;
        private CultureInfo m_cInfo;
        public List<DataUnit> dataList;

        public List<String> OperationTypes { get; set; }

        public ObservableCollection<String> OperationUnits { get; set; }

        public DataUnit Current { get; set; }

        public FromTo FromTo { get; set; }

        private float m_InputValue;
        public float InputValue
        {
            get { return m_InputValue; }
            set { m_InputValue = value; }
        }

        private string m_BaseUnit;
        public string BaseUnit
        {
            get { return m_BaseUnit; }
            set
            {
                m_BaseUnit = value;
            }
        }


        private float m_Result=0.0F;
        public float Result
        {
            get { return m_Result; }
            set { 
                m_Result = value;
                SendNotification("BaseUnit");
            }
        }
        
        public Model(string path, CultureInfo cInfo)
        {
            m_InputValue=0.0F;
            m_Result=0.0F;

            m_path = path;
            m_cInfo = cInfo;

            var data = new Data(m_path);
            dataList = data.Read(m_cInfo);

            OperationTypes = dataList.GroupBy(dataUnit => dataUnit.Type).Select(g => g.Key).ToList();

            OperationUnits = new ObservableCollection<string>();

            Current = new DataUnit();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void SendNotification(string PropertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(PropertyName));
            }
        }

    }
}
