﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFConvertionsCodingTest
{
    public class Convertion
    {

        //public static string Calculate(Model model)
			public static string Calculate(decimal valueToCalculate,decimal factor,FromTo fromTo,string unit)
        {
            string retValue;
						decimal result;


            //example: input 2km, number of m=?
            if (fromTo == FromTo.To)
            {
                result = valueToCalculate * 1.0M / factor;
                retValue = string.Format("{0} [{1}] = {2:0.000}", valueToCalculate, unit, result);
            }
            else//example: input 2m, number of km=?
            {
                result = valueToCalculate * factor;
                retValue = string.Format("{0} => {2:0.000}", valueToCalculate, result, unit);
            }

            return retValue;
        }
    }
}
