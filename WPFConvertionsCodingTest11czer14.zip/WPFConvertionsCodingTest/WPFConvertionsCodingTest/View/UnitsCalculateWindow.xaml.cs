﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFConvertionsCodingTest
{
	/// <summary>
	/// Interaction logic for UnitsCalculateWindow.xaml
	/// </summary>
	public partial class UnitsCalculateWindow : Window
	{
		public ViewModel viewModel{get;set;}

		public UnitsCalculateWindow(ViewModel _viewModel)
		{
			InitializeComponent();
			this.viewModel = _viewModel;
			this.DataContext = viewModel;

			//1.Ponizej moze nie byc konieczne,bo:
			//ComboBox powiadomi model.Current.Unit
			//model.Current.Unit = model.OperationsUnit.Take(resInt).Last();
			//model.Current.Factor = model.dataList
			//		.Where(du => du.Type.Equals(model.Current.Type) && du.Unit.Equals(model.Current.Unit))
			//		.Select(du => du.Factor).First();

			//2.Model.ValueToCalculate=Decimal.Parse(Textbox.Text);


		}

	}
}
