﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Globalization;
using System.Threading;
using System.Windows;


namespace WPFConvertionsCodingTest
{
	public class ViewModel
	{
		public Model model { get; set; }

		public Func<object, bool> f_true = new Func<object, bool>(o => { return true; });
		public ICommand bStartConvertionWindow { get; set; }

		private string m_path;
		private CultureInfo m_CultureInfo;

		public ViewModel()
		{
			m_CultureInfo = new CultureInfo("en-GB");
			Thread.CurrentThread.CurrentUICulture = m_CultureInfo;
			Thread.CurrentThread.CurrentCulture = m_CultureInfo;

			m_path = @"..\..\Units.txt";

			this.model = new Model(m_path, m_CultureInfo);
			this.bStartConvertionWindow = new CommandBase(StartConvertionWindow, f_true);
		}


		void StartConvertionWindow(object parameter)
		{
            MessageBox.Show(model.Current.Type);

			model.BaseUnit = model.dataList.Where(du => du.Type.Equals(model.Current.Type) && du.Factor == 1).First().Unit;

			model.OperationUnits.Clear();

			var Units = model.dataList.Where(dataUnit => dataUnit.Type.Equals(model.Current.Type))
			.Select(dataUnit => dataUnit.Unit).ToList();

			foreach (var item in Units)
				model.OperationUnits.Add(item);

			UnitsCalculateWindow unitWindow = new UnitsCalculateWindow(this);
			var x = unitWindow.ShowDialog().Value;
			if (x)
			{

			}


		}

	}

}
