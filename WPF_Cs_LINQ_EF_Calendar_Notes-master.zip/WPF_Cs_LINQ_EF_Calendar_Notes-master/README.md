C# Language project showing MVVM pattern in simple project: Calendar with Notes. The project enable User to store notes in LocalDB according to the calendar dates in VS 2013

New features and old staff includes:

- Fake Data Access Layer

- Columns: Hour,Minute,Note,User

- new model class: FieldsOfDataGrid.cs

 *.mdf Data Base type with Code First approach (reqiures VISUAL STUDIO 2013)

-EF 6.0 for best usage

-Simple Linq queries

-User can change Resources and Culture

Attention: Project still under constraction

To Do:

CultureInfo ci = CultureInfo.GetCultureInfo ("pl-PL");
Styles, UnityContainer - in next update.

   Author
   kbrzostowski<at>gmail.com
