﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
            string[] words = { "blueberry", "chimpanzee", "abacus", "banana", "apple", "cheese" };
              
            var wordGroups =
                from w in words
                group w by w[0] into g
                select new { FirstLetter = g.Key, Words = g };

            var nnn = wordGroups.ToDictionary(a => a, b => b);
            
            Dictionary<char, IEnumerable<string>> slownik = new Dictionary<char, IEnumerable<string>>();

            foreach (var g in wordGroups)
            {
                IEnumerable<string> slowa = g.Words;
                //Console.WriteLine("Words that start with the letter '{0}':", g.FirstLetter);
                foreach (var w in g.Words)
                {
                    //Console.WriteLine(w);
                }
                slownik.Add(g.FirstLetter, slowa);
            }

            foreach (var el in slownik)
            {
                //IEnumerable<string> slowa = g.Words;
                Console.WriteLine("Words that start with the letter '{0}':", el.Key);
                foreach (var s in el.Value)
                {
                    Console.WriteLine(s);
                }
                //slownik.Add(g.FirstLetter, slowa);
            }
            Console.WriteLine("======================");
            
            int[] array1 = { 5, 4, 1, 2, 3 };
            //
            // Use query expression on array.
            //
            var query = from element in array1
                        orderby element
                        select element;
            //
            // Convert expression to array variable.
            //
            int[] array2 = query.ToArray();
            //
            // Display array.
            //
            foreach (int value in array2)
            {
                Console.WriteLine(value);
            }

            Console.WriteLine("======================");

            IEnumerable<int> result = from value in Enumerable.Range(0, 2)
                                      select value;
            // Loop.
            foreach (int value in result)
            {
                Console.WriteLine(value);
            }

            // We can use extension methods on IEnumerable<int>
            double average = result.Average();

            // Extension methods can convert IEnumerable<int>
            List<int> list = result.ToList();
            int[] array = result.ToArray();

            Console.ReadLine();




        }
    }
}
