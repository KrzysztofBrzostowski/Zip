﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Klasa1 obiekt = new Klasa1();

            // 1
            //obiekt.Pole = 123;
            //int wartosc = obiekt.Pole;
            //MessageBox.Show(wartosc.ToString());

            // 2
            //obiekt.SetPrywatnePole(123);
            //int wartosc = obiekt.GetPrywatnePole();
            //MessageBox.Show(wartosc.ToString());

            // 3
            obiekt.Wlasciwosc = 123;
            int wartosc = obiekt.Wlasciwosc;
            MessageBox.Show(wartosc.ToString());

            /* Właściwość - używasz jak pola, działa jak metody get i set. */
        }
    }

    class Klasa1
    {
        // 1 - Publiczne pole
        public int Pole;

        // 2 - Pole prywatne, metody dostępowe (getter i setter)
        private int PrywatnePole;
        public int GetPrywatnePole() { return PrywatnePole; }
        public void SetPrywatnePole(int wartosc) { PrywatnePole = wartosc; }

        // 3 - właściwość
        private int PrywatnePole2;
        public int Wlasciwosc
        {
            get { return PrywatnePole2; }
            set { PrywatnePole2 = value; }
        }
    }
}
