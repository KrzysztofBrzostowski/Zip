﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace PracaDomowa_TestEvent_v01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<Zdarzenie> m_ListaZeZdarzeniem = new ObservableCollection<Zdarzenie>();

        ObservableCollection<Zdarzenie> ListaZeZdarzeniem
        {
            get { return m_ListaZeZdarzeniem; }
        }


        public MainWindow()
        {
            InitializeComponent();

            for (int i = 0; i < 5; i++)
            {
                Zdarzenie x = new Zdarzenie() { id = i, nazwa = "dane nr = " + i.ToString(), nazwa1 = "###" };
                Debug.WriteLine(x.ToString());
                x.Zdarz2 += new EventHandler<MyEventArgs>((s,e) => { MessageBox.Show(x.nazwa + e.MyValue.ToString()  ); });
                //x.Zdarz2 += new EventHandler<MyEventArgs>(proc_zdarz);

                ListaZeZdarzeniem.Add(x);
            }

            //comboBox1.DisplayMemberPath = "nazwa";
            comboBox1.ItemsSource = ListaZeZdarzeniem;
        }


        void proc_zdarz(object sender, MyEventArgs e)
        {
        
        //MessageBox.Show(x.nazwa + e.MyValue.ToString()); 

        }

        //UruchomZdarzenie
        private void Button01Clicked(object sender, RoutedEventArgs e)
        {

            if (comboBox1.SelectedIndex >= 0)
            {
                ListaZeZdarzeniem[comboBox1.SelectedIndex].ProcUruchomZdarzenie(comboBox1.SelectedIndex, comboBox1.SelectedIndex);
            }

        }

        //Dodaj Element
        private void button2_Click(object sender, RoutedEventArgs ee)
        {
            Zdarzenie x = new Zdarzenie() { id = 10, nazwa = "Dodano dane nr 10" };

            x.Zdarz2 += new EventHandler<MyEventArgs>((s, e) => { MessageBox.Show(x.nazwa + e.MyValue.ToString()); });

            ListaZeZdarzeniem.Add(x);
        }
    }
}
