﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PracaDomowa_TestEvent_v01
{
    public class MyEventArgs : EventArgs
    {
        public int MyValue { get; set; }
    }

    class Zdarzenie
    {

        public int id { get; set; }
        public string nazwa { get; set; }
        public string nazwa1 {get; set; }

        public event EventHandler<MyEventArgs> Zdarz2;
        //public event Action<int,int> Zdarz2;


        public void ProcUruchomZdarzenie(int SelectedIndex, int SelectedIndex_)
        {

            if (Zdarz2 != null) Zdarz2(this, new MyEventArgs() { MyValue = SelectedIndex });

        }

        public override string ToString()
        {
            return "!nr = " + nazwa;
        }

    }
}
