﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Type zmienna_typu_type;

            zmienna_typu_type = typeof(int);
            Console.WriteLine(zmienna_typu_type.Name);

            zmienna_typu_type = typeof(string);
            Console.WriteLine(zmienna_typu_type.Name);
            Console.ReadLine();
        }
    }
}
