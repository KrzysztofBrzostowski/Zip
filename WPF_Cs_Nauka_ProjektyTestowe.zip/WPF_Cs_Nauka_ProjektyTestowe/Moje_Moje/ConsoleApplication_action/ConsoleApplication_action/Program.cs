﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication_action
{
    class Program
    {



        public enum WhatHappened
        {
            ThingA,
            ThingB,
            Nothing
        }

        private delegate WhatHappened del();

        public static List<WhatHappened> DoStuff()
        {
            List<del> CheckValues = new List<del>();

            List<WhatHappened> returnValue = new List<WhatHappened> { };

            CheckValues.Add(delegate { return method1(); });
            CheckValues.Add(delegate { return method2(); });

            CheckValues.ForEach(x =>
            {
                WhatHappened wh = x();
                if (wh != WhatHappened.Nothing)
                    returnValue.Add(wh);
            });

            return returnValue;

        }

        private static WhatHappened method1()
        {
            return WhatHappened.Nothing;
        }

        private static WhatHappened method2()
        {
            return WhatHappened.ThingA;
        }




        static void Main(string[] args)
        {

            DoStuff();

        }
    }
}


