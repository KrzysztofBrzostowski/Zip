﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Runtime.InteropServices;

namespace TestDLL_uzycie_DLL
{
    class KonwerterIloczynu : IMultiValueConverter
    {

//__declspec(dllexport) int __cdecl pomnoz(int a,int b)

        //[DllImport("TestDLL_tworzenie_wC")] 
        [DllImport("HidDevice01")]
        public static extern int pomnoz(int a, int b);

        #region IMultiValueConverter Members

        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            int resultat = 1;
            int l1,l2;

            //for (int i = 0; i < values.Length; i++)
            //{                resultat *= (int)values[i];            }

            l1 = (int)values[0];
            l2 = (int)values[1];


            resultat=pomnoz(l1,l2);
            return resultat;

            //throw new NotImplementedException();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
