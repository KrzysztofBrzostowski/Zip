﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TestDLL_uzycie_DLL
{
    class Model : INotifyPropertyChanged
    {
        public Model()
        {

        }

        private int m_liczbaA=1;

        public int LiczbaA
        {
            get { return m_liczbaA; }
            set
            {
                m_liczbaA = value;
                RaisePropertyChanged("LiczbaA");
            }
        }


        private int m_liczbaB=1;

        public int LiczbaB
        {
            get { return m_liczbaB; }
            set
            {
                m_liczbaB = value;
                RaisePropertyChanged("LiczbaB");
            }

        }


        private void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this,new PropertyChangedEventArgs(propertyName));
        }



        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
