﻿using System;
//using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Data;

namespace DataSet_
{
    class Program
    {
        static void Main(string[] args)
        { 
            // Create two DataTable instances.
            DataTable table1 = new DataTable("pracownicy");
            table1.Columns.Add("nazwisko");
            table1.Columns.Add("id");
            table1.Rows.Add("jan", 1);
            table1.Rows.Add("karol", 2);

            DataTable table2 = new DataTable("adresy");
            table2.Columns.Add("id");
            table2.Columns.Add("ulica");
            table2.Rows.Add(1, "Andersena");
            table2.Rows.Add(2, "Kasprowicza");

            // Create a DataSet and put both tables in it.
            DataSet set = new DataSet("BazaDanych");
            set.Tables.Add(table1);
            set.Tables.Add(table2);

            // Visualize DataSet.
            Console.WriteLine(set.GetXml());
            Console.ReadLine();







        }







    }
}
