﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Destructor_Finalizator_Example
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Odziedziczona inh_var;

        public MainWindow()
        {
            InitializeComponent();
            //var myRes = new Odziedziczona();
            inh_var = new Odziedziczona();


            //using (var resource = new Odziedziczona())
            //{
                
            //}


        }
    }
}
