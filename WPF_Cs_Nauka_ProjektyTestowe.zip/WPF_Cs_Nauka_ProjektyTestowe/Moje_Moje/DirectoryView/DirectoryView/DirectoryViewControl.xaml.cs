﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;


//Path.GetPathRoot

namespace DirectoryView
{
    /// <summary>
    /// Interaction logic for DirectoryViewControl.xaml
    /// </summary>
    public partial class DirectoryViewControl : UserControl
    {

        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //TrewView ma takiego propertisa jak SelectedItem

        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //Path.GetPathRoot

        public string Sciezka { get; set; }

        public DirectoryViewControl()
        {
            InitializeComponent();

            //event tej kontrolki; uruchamia sie gdy kontrolka zostala wyswietlona
            Loaded += new RoutedEventHandler(DirectoryViewControl_Loaded);
        }


        //TreeViewItem jest lisciem, jest wezlem ( w szczegolnosc lisciem)
        void DirectoryViewControl_Loaded(object sender, RoutedEventArgs e)
        {
            //DriveInfo.GetDrives() statyczna metoda pobierajaca dyski z systemu
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {

                if (drive.Name == "C:\\") continue;

                //w drive bede mial dyski. Jest to klasa opisujaca dyski
                //dla kazdego dysku chce utworzyc wezel drzewa.
                //nowa instancja wezla

                TreeViewItem item = new TreeViewItem();

                //pomocniczy propertis
                //ta informacja bedzie wykorzystywana aby dowiedziec sie ktory dysk 
                //nalezy rozwinac dla kazdego z wezlow w handlerze zdarzenia Expanded
                item.Tag = drive;
                item.Header = drive.ToString();

                //teraz dodajemy wezel "dziecko",zeby wezel dysku byl rozwijalny
                item.Items.Add("*");

                //z ksiazki
                //foreach ( DirectoryInfo subdir in dir.get

                //dodac handler ewentu Expanded

                //jezeli wezel drzewa nie ma dzieci to nie jest rozwijalny
                treeView_InstanceName.Items.Add(item);

            }


        }

        private void treeView_InstanceName_Expanded(object sender, RoutedEventArgs e)
        {
            TreeViewItem item = (TreeViewItem)e.OriginalSource;
            item.Items.Clear();

            DirectoryInfo dir;
            if (item.Tag is DriveInfo)
            {
                DriveInfo drive = (DriveInfo)item.Tag;
                dir = drive.RootDirectory;

            }
            else
            {
                dir = (DirectoryInfo)item.Tag;
            }

            try
            {
                foreach (DirectoryInfo subdir in dir.GetDirectories())
                {
                    TreeViewItem newItem = new TreeViewItem();
                    newItem.Tag = subdir;
                    newItem.Header = subdir.ToString();
                    newItem.Items.Add("*");
                    item.Items.Add(newItem);

                    //Directory.GetFiles;

                }

                foreach (FileInfo file in dir.GetFiles())
                {
                    TreeViewItem newItem = new TreeViewItem();
                    newItem.Tag = file;
                    newItem.Header = file.ToString();
                    //newItem.Items.Add("*");
                    item.Items.Add(newItem);

                    //Directory.GetFiles;

                }




            }
            catch (Exception ex)
            {
                MessageBox.Show("Blad dostepu. " + ex.Message.ToString());
            }

        }


        //ButtonOK
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string sciezka;
            TreeViewItem item;
            item = ((TreeViewItem)treeView_InstanceName.SelectedItem);

            if (item == null) { MessageBox.Show("Zaznacz katalog"); return; }

            DirectoryInfo dir;
            if (item.Tag is DriveInfo)
            {
                DriveInfo drive = (DriveInfo)item.Tag;
                dir = drive.RootDirectory;
            }
            else if (item.Tag is DirectoryInfo)
            {
                dir = (DirectoryInfo)item.Tag;
            }
            else
            //if (item.Tag is FileInfo)
            {
                FileInfo fi = (FileInfo)item.Tag;
                sciezka = fi.Name.ToString();
                MessageBox.Show(sciezka);
                return;
            }

            DirectoryInfo d_g;
            d_g = dir;



            if (d_g.Name.ToString().Equals(d_g.Root.ToString()))
            {
                sciezka = d_g.Name.ToString();
            }
            else
            {
                sciezka = d_g.Name.ToString();
                while (d_g.Parent.ToString() != "")
                {
                    d_g = d_g.Parent;
                    sciezka = d_g.ToString() + "\\" + sciezka;
                }
                sciezka = d_g.Root.ToString() + sciezka;
            }

            MessageBox.Show(sciezka);

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            //this.Close();
        }
    }




}
