﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


namespace DostepDoBazy
{
    class DAL
    {
        SqlConnection cn = new SqlConnection();

        public DAL()
        {

            cn.ConnectionString =
//@"Server=.\NAZWA_INSTANCJI;AttachDbFilename=C:\Program Files\Microsoft SQL Server\MSSQL10_50.NAZWA_INSTANCJI\MSSQL\DATA\testowa.mdf;Database=tesowa; Trusted_Connection=Yes;";
@"Data Source=ELA-KOMPUTER\NAZWA_INSTANCJI;Initial Catalog=testowa;Integrated Security=SSPI;";

        }

        public List<Produkt> PobierzProdukty()
        {
            List<Produkt> retList = new List<Produkt>();
            cn.Open();

            using (SqlCommand cmd = cn.CreateCommand())
            {
                cmd.CommandText = "Select * from vwProduktyKategorie0";

                using (SqlDataReader dr = cmd.ExecuteReader())
                    while (dr.Read())
                    {
                        var p = new Produkt();
                        p.ProduktID = (int)dr["ProduktID"];
                        p.Nazwa = dr["NazwaProduktu"].ToString();
                        p.Kategoria = dr["NazwaKategorii"].ToString();
                        p.Cena = (decimal) dr ["Cena"];
                        retList.Add(p);
                    }
            }

            return retList;
        }


    }
}

