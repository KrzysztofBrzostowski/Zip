﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DostepDoBazy
{
    class Produkt
    {

        public int  ProduktID { get; set; }
        public string Nazwa { get; set; }
        public string Kategoria { get; set; }
        public decimal Cena { get; set; }

    }
}
