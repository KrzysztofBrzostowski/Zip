﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Graphics
{
	/// <summary>
	/// Interaction logic for Clock.xaml
	/// </summary>
	public partial class Clock : FrameworkElement
	{
		private DispatcherTimer m_Timer = new DispatcherTimer();

		public Clock()
		{
			InitializeComponent();

			m_Timer.Tick += new EventHandler(m_Timer_Tick);
			m_Timer.Interval = new TimeSpan(0, 0, 0, 0, 100);
			m_Timer.Start();
		}

		private void m_Timer_Tick(object sender, EventArgs e)
		{
			InvalidateVisual();
		}

		protected override void OnRender(DrawingContext drawingContext)
		{
			base.OnRender(drawingContext);

			double radius = ActualHeight * 0.4;
			Point centerPoint = new Point(ActualWidth / 2, ActualHeight / 2);
			Pen circlePen = new Pen(Brushes.Blue, 2);

			drawingContext.DrawEllipse(Brushes.Wheat, circlePen, centerPoint, radius, radius);

			double angle = DateTime.Now.Second * Math.PI * 2 / 60;
			double x = Math.Cos(angle) * radius;
			double y = Math.Sin(angle) * radius;

			Point arrowEndPoint = new Point(x + ActualWidth / 2, y + ActualHeight / 2);

			drawingContext.DrawLine(circlePen, centerPoint, arrowEndPoint);
		}
	}
}
