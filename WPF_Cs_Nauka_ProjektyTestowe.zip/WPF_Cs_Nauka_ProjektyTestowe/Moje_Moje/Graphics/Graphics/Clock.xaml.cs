﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Graphics
{
	/// <summary>
	/// Interaction logic for Clock.xaml
	/// </summary>
	public partial class Clock : FrameworkElement
	{
		private DispatcherTimer m_Timer = new DispatcherTimer();

		public Clock()
		{
			InitializeComponent();

			m_Timer.Tick += new EventHandler(m_Timer_Tick);
			m_Timer.Interval = new TimeSpan(0, 0, 0, 0, 100);
			m_Timer.Start();
		}

		private void m_Timer_Tick(object sender, EventArgs e)
		{
			InvalidateVisual(); 
		}

		protected override void OnRender(DrawingContext drawingContext)
		{
			base.OnRender(drawingContext);

			double radius = ActualHeight * 0.4;
			Point centerPoint = new Point(ActualWidth / 2, ActualHeight / 2);
			Pen circlePen = new Pen(Brushes.GreenYellow, 2);
            Pen mojPen1 = new Pen(Brushes.Blue, 3);

            Pen mojPen2 = new Pen(Brushes.DarkViolet, 3);
          
            //circlePen.DashStyle = DashStyle.DashesProperty.

            //HatchBrush v;

			drawingContext.DrawEllipse(Brushes.Aqua, circlePen, centerPoint, radius, radius);

			double angle = DateTime.Now.Second * Math.PI * 2 / 60;
			double x_ = Math.Cos(angle) * radius;
			double y_ = Math.Sin(angle) * radius;

			Point arrowEndPoint = new Point(x_  + ActualWidth / 2 , y_ + ActualHeight / 2 );

            double yi, y_poprz=0.0+ActualHeight/2.0,x,x_poprz=0.0;

            double xp = 0.0;
            for (int xi = 180; xi < ActualWidth + 180; xi++)
            {
                yi = 50.0 * Math.Sin(Math.PI*((double)xi)/180.0) + ((double)ActualHeight)/2.0;

                drawingContext.DrawLine(mojPen1, new Point(x_poprz,y_poprz)  , new Point (xp,yi) );
                xp += 1.0;
                y_poprz = yi;
                x_poprz = xp;
            }


            y_poprz = 0.0 + ActualHeight / 2.0; x_poprz = 0.0;


            xp = 0.0;
            for (int xi = 180,nr_p=0; xi < ActualWidth + 180; xi++,nr_p++)
            {
                yi = 50.0 * Math.Cos(Math.PI * ((double)xi) / 180.0) + ((double)ActualHeight) / 2.0;

                if (nr_p == 0) y_poprz = yi;

                drawingContext.DrawLine(mojPen2, new Point(x_poprz, y_poprz), new Point(xp, yi));
                xp += 1.0;
                y_poprz = yi;
                x_poprz = xp;
            }





			drawingContext.DrawLine(circlePen, centerPoint, arrowEndPoint);
		}
	}
}
