﻿using System;
//using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;

namespace HidCommubicationDemo
{
    /*
    public struct strHidDevice
    {

        //! Handle for hid device
        IntPtr hndHidDevice;
        //! Indicator if device is opened
        bool bDeviceOpen;

        //! Timeout for GetReport requests
        uint uGetReportTimeout;
        //! Timeout for SetReport requests
        uint uSetReportTimeout;

        //! Asynchronous I/O structure
        OVERLAPPED oRead;
        //! Asynchronous I/O structure
        OVERLAPPED oWrite;

        //! Maximum length of InReport's
        Int16 wInReportBufferLength;
        //! Maximum length of OutReport's
        Int16 wOutReportBufferLength;

        //! InBuffer contains data, if InReport provides more data then the application actual need
        byte[] inBuffer = new byte[8192];
        //! Number of current used bytes in inBuffer
        Int16 inBufferUsed;
    };
     */

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct strTrackSerialNumbers
    {
        //! Index number
        //[MarshalAsAttribute(UnmanagedType.U8)]
        public ulong deviceNum;

        //! Serial number of physical device 
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 40)]
        //        [MarshalAsAttribute(UnmanagedType.LPStr, SizeConst=40)]
        //        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 40)]
        public char[] serialNum;
    }


    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct strHidDevice
    {

        //! Handle for hid device
        //typedef void *HANDLE;
        IntPtr hndHidDevice;

        //! Indicator if device is opened
        bool bDeviceOpen;

        //! Timeout for GetReport requests
        //typedef unsigned int        UINT;
        //UINT uGetReportTimeout;
        UInt32 uGetReportTimeout;

        //! Timeout for SetReport requests
        //typedef unsigned int        UINT;
        UInt32 uSetReportTimeout;

        //! Asynchronous I/O structure
        //OVERLAPPED oRead;    
        NativeOverlapped oRead;

        //! Asynchronous I/O structure
        //OVERLAPPED oWrite;
        NativeOverlapped oWrite;

        //! Maximum length of InReport's
        UInt16 wInReportBufferLength;

        //! Maximum length of OutReport's
        UInt16 wOutReportBufferLength;

        //! InBuffer contains data, if InReport provides more data then the application actual need

        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 8192)]
        byte[] inBuffer;
        //! Number of current used bytes in inBuffer
        //WORD
        ushort inBufferUsed;
    } ;




    public static class HidAdapter
    {
        [DllImport("HidDevice01.dll")]
        public static extern IntPtr HID_DeviceCreate();

        [DllImport("HidDevice01.dll")]
        public static extern void HID_Init(ref strHidDevice deviceHandler);

        [DllImport("HidDevice01.dll")]
        public static extern ulong HID_GetSerNums(UInt16 vid, UInt16 pid, out strTrackSerialNumbers serialNumList);

        [DllImport("HidDevice01.dll")]
        public static extern bool HID_IsDeviceAffected(IntPtr deviceHandler);


        /*        
            public static extern int puts( [MarshalAs(UnmanagedType.LPStr)] string m);
                    [MarshalAsAttribute(UnmanagedType.ByValArray , SizeConst=40)]
        */
        [DllImport("HidDevice01.dll", CharSet = CharSet.Ansi)]
        public static extern byte HID_Open(ref strHidDevice deviceHandler,
            UInt16 vid,
            UInt16 pid,
            ulong deviceIndex,
//            [MarshalAsAttribute(UnmanagedType.)]
//            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 40)]
 //             [MarshalAs(UnmanagedType.ByValArray , SizeConst = 40)]
            char[] serialNumber,
            ulong totalDevNum,
            ulong totalSerNum);





        /*
        __declspec(dllexport) BYTE HID_Open(struct strHidDevice* pstrHidDevice, 
                      WORD vid, 
                      WORD pid, 
                      DWORD deviceIndex, 
                      char serialNumber[SERNUM_LEN],
                      DWORD totalDevNum,
                      DWORD totalSerNum);
        */


    }

    class Program
    {
        static void Main(string[] args)
        {

            //Console.WriteLine("{0}", sizeof(char)); 
            //Console.ReadLine();

            strHidDevice deviceHandler = new strHidDevice();

            //deviceHandler = HidAdapter.HID_DeviceCreate();
            //strHidDevice m_strHidDevice;// = new strHidDevice();

            //HidAdapter.HID_Init(deviceHandler);
            HidAdapter.HID_Init(ref deviceHandler);


            strTrackSerialNumbers serialNums = new strTrackSerialNumbers();
            //serialNums.serialNum = new char[40]; 
            ulong x = HidAdapter.HID_GetSerNums((UInt16)0x046d, (UInt16)0xc20b, out serialNums);

            //bool y = HidAdapter.HID_IsDeviceAffected(deviceHandler);



        }
    }
}
