﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Threading;

namespace WpfApplication1
{

    interface ISaver 
    {
        void Save(DateTime time);
    }

    class nowa
    {
    }

    class jescze_jedna
    {
    }


    class Zegar
    {
        public ISaver Saver;// { get; set; }
        private DispatcherTimer m_Timer = new DispatcherTimer();
        public Zegar()
        {
            m_Timer.Tick += new EventHandler(m_Timer_Tick);
            m_Timer.Interval = new TimeSpan(0, 0, 1);
            m_Timer.Start();
        }

        void m_Timer_Tick(object sender, EventArgs e)
        {
            if (Saver == null)
                return;

            Saver.Save(DateTime.Now);
            //throw new NotImplementedException();
        }
    }

    class FileSaver : ISaver
    {
        public void Save(DateTime time)
        {
            //zapisuje do pliku
            //throw new NotImplementedException();
        }
    }

    class ConsoleSaver : ISaver
    {
        public void Save(DateTime time)
        {
            //zaspisuje na konsole
            //throw new NotImplementedException();
        }
    }
}
