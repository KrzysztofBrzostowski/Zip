﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
//using Microsoft.Practices.Prism.Commands;
//using Microsoft.Practices.Composite.Presentation.Commands;

namespace KontrolkaSaveAs
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class SaveFileDialog01 : Window
    {



        private string m_NazwaPliku =string.Empty;
        public string FileName
        {
            get
            {
                return m_NazwaPliku;
            }

            set
            {
                m_NazwaPliku = value;
            }
        }

        public SaveFileDialog01()
        {
            InitializeComponent();

            /*
            ButtonScreenKeyBoardPressedCommand = new DelegateCommand
                (
                OnButtonScreenKeyBoardPressedCommand,
                OnButtonScreenKeyBoardCanExecute
                );


            ButtonOKPressedCommand = new DelegateCommand
                (
                OnButtonOKPressedCommand,
                OnButtonOKCanExecute
                );


            ButtonCancelPressedCommand = new DelegateCommand
                (
                OnButtonCancelPressedCommand,
                OnButtonCancelCanExecute
                );
            */
            DataContext = this;
        }

        private void ButtonScreenKeyBoard_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Jeszcze nie gotowe!");
        }

        private void ButtonOK_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.FileName = string.Empty;
            this.Close();
        }

        /*
        //nasza klawiatura
        private void OnButtonScreenKeyBoardPressedCommand()
        {
        }

        private bool OnButtonScreenKeyBoardCanExecute()
        {
            return true;
        }

        private void OnButtonOKPressedCommand()
        {
        }
        
        private bool OnButtonOKCanExecute()
        {
            return true;
        }

        private void OnButtonCancelPressedCommand()
        {
        }

        private bool OnButtonCancelCanExecute()
        {
            return true;
        }
        */
        

    }

            
    




}
