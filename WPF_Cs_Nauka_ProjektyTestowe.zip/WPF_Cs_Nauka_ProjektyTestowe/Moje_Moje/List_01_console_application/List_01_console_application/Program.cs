﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace List_01_console_application
{

// http://www.csharp-station.com/Tutorials/Lesson01.aspx


    class Program
    {
        static void Main(string[] args)
        {


            /*

            using System;

            public class SamplesArray
            {
                public static void Main()
                {
                    // create a three element array of integers
                    int[] intArray = new int[] {2, 3, 4};

                    // set a delegate for the ShowSquares method
                    Action<int> action = new Action<int>(ShowSquares);

                    Array.ForEach(intArray, action);
                }

                private static void ShowSquares(int val)
                {
                    Console.WriteLine("{0:d} squared = {1:d}", val, val*val);
                }
            }



            */



            /*
                        google: .net dictionary example
                        http://www.dotnetperls.com/dictionary

                        This tip is not in every beginner's C# book: when Dictionary, 
                        or any object that implements IDictionary, is used in a foreach loop, 
                        it returns an enumeration. In the case of Dictionary, this enumeration is in the form of KeyValuePair values.

            */

            //Console.Write("Hello, {0}! ", Console.ReadLine());
            //string name = Console.ReadLine(); 

//--------------------------------------------------

//Convert

            /*


                        class Program
            {
                static void Main()
                {
                // Convert 'text' string to an integer with Convert.ToInt32.
                string text = "500";
                int num = Convert.ToInt32(text);
                Console.WriteLine(num);
                }
            }

 
             */


            /*

                static void Main()
                {
                // Convert string to number.
                string text = "500";
                int num = int.Parse(text);
                Console.WriteLine(num);
                }


            */


            //Try parse

            /*

                static void Main()
                {
                bool flag1 = IsNumber("1000");
                bool flag2 = IsNumber("-11");
                bool flag3 = IsNumber("Nope");

                Console.WriteLine(flag1);
                Console.WriteLine(flag2);
                Console.WriteLine(flag3);
                }

                static bool IsNumber(string value)
                {
                // Return true if this is a number.
                int number1;
                return int.TryParse(value, out number1);
                }

            */


            /*

                 static void Main()
                {
                Console.WriteLine("Type an integer:");
                string line = Console.ReadLine(); // Read string from console
                int value;
                if (int.TryParse(line, out value)) // Try to parse the string as an integer
                {
                    Console.Write("Multiply integer by 10: ");
                    Console.WriteLine(value * 10); // Multiply the integer and display it
                }
                else
                {
                    Console.WriteLine("Not an integer!");
                }
                }


            */

            //----------------- Array------------------
            /*

                            public static void Main()
                {
                    int[] myInts = { 5, 10, 15 };
                    bool[][] myBools = new bool[2][];
                    myBools[0] = new bool[2];
                    myBools[1] = new bool[1];
                    double[,] myDoubles = new double[2, 2];
                    string[] myStrings = new string[3];

                    Console.WriteLine("myInts[0]: {0}, myInts[1]: {1}, myInts[2]: {2}", myInts[0], myInts[1], myInts[2]);

                    myBools[0][0] = true;
                    myBools[0][1] = false;
                    myBools[1][0] = true;
                    Console.WriteLine("myBools[0][0]: {0}, myBools[1][0]: {1}", myBools[0][0], myBools[1][0]);

                    myDoubles[0, 0] = 3.147;
                    myDoubles[0, 1] = 7.157;
                    myDoubles[1, 1] = 2.117;
                    myDoubles[1, 0] = 56.00138917;
                    Console.WriteLine("myDoubles[0, 0]: {0}, myDoubles[1, 0]: {1}", myDoubles[0, 0], myDoubles[1, 0]);

                    myStrings[0] = "Joe";
                    myStrings[1] = "Matt";
                    myStrings[2] = "Robert";
                    Console.WriteLine("myStrings[0]: {0}, myStrings[1]: {1}, myStrings[2]: {2}", myStrings[0], myStrings[1], myStrings[2]);

                }


            */

//----------------------------------------------------------------

//Dictionary

/*
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
	// Use the dictionary.
	Dictionary<string, int> dict = new Dictionary<string, int>();
	dict.Add("cat", 1);
	dict.Add("dog", 4);

	Console.WriteLine(dict["cat"]);
	Console.WriteLine(dict["dog"]);
    }
}
*/


            /*

            using System;
            using System.Collections.Generic;

            class DictionaryExample
            {
            public static void Main()
            {
            Dictionary dict = new Dictionary();

            // Add elements to the collection.
            dict.Add("A", 52);
            dict.Add("B", 72);
            dict.Add("C", 110);
            dict.Add("D", 63);
            dict.Add("E", 100);

            foreach (string str in dict.Keys)
            Console.WriteLine("At key {0} , value is {1}", str, dict[str]);

            Console.ReadLine();
            }
            }
 
             */



//ponizej nie wiadomo czy "working"

            /*
             public class MyClass
{
  public MyClass()
  {
    TheDictionary = new Dictionary<int, string>();
  }

  // private setter so no-one can change the dictionary itself
  // so create it in the constructor
  public IDictionary<int, string> TheDictionary { get; private set; }
}
 
              

             MyClass mc = new MyClass();

            mc.TheDictionary.Add(1, "one");
            mc.TheDictionary.Add(2, "two");
            mc.TheDictionary.Add(3, "three");

            Console.WriteLine(mc.TheDictionary[2]);

 
            */


            /*
               public class Customer
                {
                    public Customer(int id, string name)
                    {
                        ID = id;
                        Name = name;
                    }

                    private int m_id;

                    public int ID
                    {
                        get { return m_id; }
                        set { m_id = value; }
                    }

                    private string m_name;

                    public string Name
                    {
                        get { return m_name; }
                        set { m_name = value; }
                    }

     Dictionary<int, Customer> customers = new Dictionary<int, Customer>();

    Customer cust1 = new Customer(1, "Cust 1");
    Customer cust2 = new Customer(2, "Cust 2");
    Customer cust3 = new Customer(3, "Cust 3");

    customers.Add(cust1.ID, cust1);
    customers.Add(cust2.ID, cust2);
    customers.Add(cust3.ID, cust3);

    foreach (KeyValuePair<int, Customer> custKeyVal in customers)
    {
        Console.WriteLine(
            "Customer ID: {0}, Name: {1}",
            custKeyVal.Key,
            custKeyVal.Value.Name);
    }

 
             */

            foreach (string s in args)
            {
                System.Console.WriteLine(s);
            }

            Console.ReadLine();

        }
    }
}
