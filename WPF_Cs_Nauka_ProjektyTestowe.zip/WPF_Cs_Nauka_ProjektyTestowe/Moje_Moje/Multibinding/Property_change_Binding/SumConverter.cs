﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace Property_change_Binding 
{
    class SumConverter : IMultiValueConverter
    {
        #region IMultiValueConverter Members


        // tablica [] values bo wiele wartosci jako zrodlo
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //kazda wartosc chcemy zrzuitowac na int i dodac do jakiejs liczby i zwrpococ sume

            int resultat = 0;

            for (int i = 0; i < values.Length; i++)
            {
                resultat += (int) values[i];


            }

            return resultat;

            //throw new NotImplementedException();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
