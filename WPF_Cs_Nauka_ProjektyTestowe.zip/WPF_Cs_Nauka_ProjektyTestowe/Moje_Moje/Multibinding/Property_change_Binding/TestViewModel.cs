﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Property_change_Binding
{
    public class TestViewModel : INotifyPropertyChanged
    {


        //right click -> refactor-> encapsulate field
        private int m_Value1;

        public int Value1
        {
            get { return m_Value1; }
            set
            {
                m_Value1 = value;
                RaisePropertyChanged("Value1");
            }
        }

        private int m_Value2;

        public int Value2
        {
            get { return m_Value2; }
            set
            {
                m_Value2 = value;
                RaisePropertyChanged("Value2");
                //tu zmienia sie propertis, a nie zmienna m_Value2  !!!!
            }
        }



        //okienko podlacza sie do danych,
        //okienko window1
        public TestViewModel()
        {
           
        }

    
        

        private void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));

        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

}
