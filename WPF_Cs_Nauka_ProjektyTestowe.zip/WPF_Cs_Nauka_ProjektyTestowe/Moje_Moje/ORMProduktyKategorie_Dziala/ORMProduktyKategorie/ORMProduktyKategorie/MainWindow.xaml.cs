﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ORMProduktyKategorie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            SklepEntities sklep = new SklepEntities();
            InitializeComponent();

            comboBox1.ItemsSource = sklep.Kategorie;


        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //zmiana przy wyselekcjowangeo elmenti\u
            dataGrid1.ItemsSource = ((Kategorie)comboBox1.SelectedItem).Produkty;
        }
    }
}
