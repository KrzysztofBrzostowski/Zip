﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Timers;

namespace Observable_Collection_Sample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        ObservableCollection<string> TheList;

        public MainWindow()
        {
            InitializeComponent();


            TheList = new ObservableCollection<string>();
            DemoLB.ItemsSource = TheList;
            DataGrid1.ItemsSource = TheList;

        }


        private void AddSomething_Click(object sender, RoutedEventArgs e)
        {
            TheList.Add(DateTime.Now.ToString());

            if (DemoLB.ItemsSource == null) DemoLB.ItemsSource = TheList;
            if (DataGrid1.ItemsSource == null) DataGrid1.ItemsSource = TheList;

            //TheList.Add("123");

        }

        private void b01_Click(object sender, RoutedEventArgs e)
        {
            TheList.Clear();
            DemoLB.ItemsSource = null;
            DataGrid1.ItemsSource = null;

            //this.dataGrid1.Items.Refresh();
            //DemoLB.Items.Refresh();

        }

    }
}
