﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication1
{
    class Kubek
    {

        private int wielkosc;
    
        public int Wielkosc
        {
            get { return wielkosc; }
            set { wielkosc = value; }
        }
      


        //int get_()
        //{
        //    return wielkosc;
        //}

        //void set_(int wielkosc)
        //{ this.wielkosc = wielkosc; }

      

    }
}
