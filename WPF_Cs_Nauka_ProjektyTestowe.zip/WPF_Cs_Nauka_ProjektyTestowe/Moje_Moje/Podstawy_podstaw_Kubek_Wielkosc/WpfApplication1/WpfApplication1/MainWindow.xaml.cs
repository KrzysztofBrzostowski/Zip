﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        Kubek m_Kubek = new Kubek();//na poziomie klasy robi sie podkreslenie

        //Kubek m_Kubek;

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = m_Kubek;

           //m_Kubek = new Kubek();

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //label1.Content = textBox1.Text;
            //App.Current.Shutdown();
            //

            MessageBox.Show(m_Kubek.Wielkosc.ToString());

        }
    }
}
