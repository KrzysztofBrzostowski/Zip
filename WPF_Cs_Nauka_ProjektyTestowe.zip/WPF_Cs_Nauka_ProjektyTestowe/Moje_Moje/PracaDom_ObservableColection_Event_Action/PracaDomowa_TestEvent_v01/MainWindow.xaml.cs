﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace PracaDomowa_TestEvent_v01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<Zdarzenie> m_ListaZeZdarzeniem = new ObservableCollection<Zdarzenie>();

        ObservableCollection<Zdarzenie> ListaZeZdarzeniem
        {
            get { return m_ListaZeZdarzeniem; }
        }


        public MainWindow()
        {
            InitializeComponent();

            for (int i = 0; i < 5; i++)
            {
                Zdarzenie x = new Zdarzenie() { id = i, nazwa = "dane nr = " + i.ToString() };
                x.Zdarz2 += new Action<int, int>((int index, int index2) => { MessageBox.Show(x.nazwa + index.ToString()); });

                ListaZeZdarzeniem.Add(x);
            }

            comboBox1.DisplayMemberPath = "nazwa";
            comboBox1.ItemsSource = ListaZeZdarzeniem;
        }

        private void Button01Clicked(object sender, RoutedEventArgs e)
        {

            if (comboBox1.SelectedIndex >= 0)
            {
                ListaZeZdarzeniem[comboBox1.SelectedIndex].ProcUruchomZdarzenie(comboBox1.SelectedIndex, comboBox1.SelectedIndex);
            }

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {


            Zdarzenie x = new Zdarzenie() { id = 10, nazwa = "Dodano dane nr 10" };


            x.Zdarz2 += new Action<int, int>((int index, int index2) => { MessageBox.Show(x.nazwa + index.ToString()); });

            ListaZeZdarzeniem.Add(x);


        }
    }
}
