﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PracaDomowa_TestEvent_v01
{
    class Zdarzenie
    {

        public int id { get; set; }
        public string nazwa { get; set; }

        //public event EventHandler Zdarz1;
        public event Action Zdarz2;


        public void ProcUruchomZdarzenie()
        {

            if (Zdarz2 != null) Zdarz2();

        }

        public override string ToString()
        {
            return  "!nr = " + nazwa;
        }

    }
}
