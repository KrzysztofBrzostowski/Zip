﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DllControls
{
    public class Class1
    {
    }
}
