﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DllControls
{
    /// <summary>
    /// Interaction logic for UpDownBox.xaml
    /// </summary>
    public partial class UpDownBox : UserControl
    {
        public UpDownBox()
        {
            InitializeComponent();
        }




        public static readonly DependencyProperty
            ValProperty =
            DependencyProperty.Register ("Val",
                                                        typeof(int),
                                                        typeof(UpDownBox),
                                                        new PropertyMetadata(0,
                                                            new PropertyChangedCallback(ValCallback),
                                                            new CoerceValueCallback(ValCoerce)
                                                            )
                                                            );

        public int Val
        {
            get { return (int)GetValue(ValProperty); }
            set { SetValue(ValProperty, value); }
        }



        private static object ValCoerce(DependencyObject d, object baseValue)
        {

            return baseValue;
        }


        private static void ValCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            //BrowserControl bc = (BrowserControl)d;
            //bc.mojTextBlock.Text = e.NewValue.ToString();

            UpDownBox udb = (UpDownBox)d;
            //udb.Val = (int)e.OldValue + (int) Step; //czemu to sie nie kompiluje?

            udb.mojTextBox.Text = e.NewValue.ToString();


        }

        private void ValPlusStep_Click(object sender, RoutedEventArgs e)
        {
            Val+=Step;
            //mojTextBox.Text = Val.ToString();
        }

/////////////////////////////////////////////



        public static readonly DependencyProperty
            StepProperty =
            DependencyProperty.Register("Step",
                                                        typeof(int),
                                                        typeof(UpDownBox),
                                                        new PropertyMetadata(7,
                                                            new PropertyChangedCallback(StepCallback),
                                                            new CoerceValueCallback(StepCoerce)
                                                            )
                                                            );

        public int Step
        {
            get { return (int)GetValue(StepProperty); }
            set { SetValue(StepProperty, value); }
        }



        private static object StepCoerce(DependencyObject d, object baseValue)
        {

            return baseValue;
        }


        private static void StepCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            //BrowserControl bc = (BrowserControl)d;
            //bc.mojTextBlock.Text = e.NewValue.ToString();

            UpDownBox udb = (UpDownBox)d;
            udb.mojTextBox.Text = e.NewValue.ToString();

        }

        private void ValMinusStep_Click(object sender, RoutedEventArgs e)
        {
            Val -= Step;
            //mojTextBox.Text = Val.ToString();
        }








    }
}
