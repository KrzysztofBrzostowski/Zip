﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Dziwna_Klasa_w_App_Konmsiolowej
    {
    }
}
