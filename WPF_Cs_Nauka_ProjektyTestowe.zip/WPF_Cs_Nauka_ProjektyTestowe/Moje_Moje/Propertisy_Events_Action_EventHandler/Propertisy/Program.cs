﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Propertisy2;

namespace Propertisy
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            PropertyTest instancjaKlasyTest = new PropertyTest();
            // Tutaj będzie błąd
            instancjaKlasyTest.Property1 = "ddd";
             */

            EventTest test = new EventTest();
            test.PodniesionoAlarm += new EventHandler(test_PodniesionoAlarm);
            test.PodniesionoAlarm2 += new Action(test_PodniesionoAlarm2);

            test.Start();

            Console.ReadLine();
        }

        static void test_PodniesionoAlarm2()
        {
            Console.WriteLine("test_PodniesionoAlarm2 ");
//               throw new NotImplementedException();
        }

        //ta metoda zostanie urichomiona 
        //za kazdym razem gdy Klasa EventTest cos znajudzie
        //(posniesieAlarm)
        private static void test_PodniesionoAlarm(object sender, EventArgs e)
        {
            Console.WriteLine("test_PodniesionoAlarm ");
        }
    }
}
