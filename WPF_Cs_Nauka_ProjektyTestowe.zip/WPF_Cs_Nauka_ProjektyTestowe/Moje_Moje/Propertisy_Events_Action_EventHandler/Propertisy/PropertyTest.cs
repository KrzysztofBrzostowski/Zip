﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Propertisy
{
    public class PropertyTest //warto wpisywac public
    {
        private string m_Text;
        //  Encapsulate field - uprasdzczA TWORZENIE WŁASCIWOSCI
        public string Text
        {
            get { return m_Text; }
            set { m_Text = value; }
        }

        private int m_Count;

        //kompiltor stowurzy sobie zmninna pomocnicza
        public string Property1
        {
            get;
            private set;
        }

        public int Count
        {
            get { return m_Count; }

            set
            {
                m_Count = value;
                Console.WriteLine(m_Count);
            }
        }
    }
}
