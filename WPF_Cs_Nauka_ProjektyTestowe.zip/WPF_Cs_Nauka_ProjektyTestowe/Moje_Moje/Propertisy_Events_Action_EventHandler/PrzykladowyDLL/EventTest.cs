﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Propertisy2
{
    public class EventTest
    {
        public void Start()
        {
            for (int i = 0; i < 5; i++)
            {
                PodniesionoAlarm(this, new EventArgs());
                PodniesionoAlarm2();
            }
        }

        //dobrze jest uzyeac EventHJandkler bo wtedy mozemy porzekzac this,
        //trzymamy sie wskazan Micrososoftu
        public event EventHandler PodniesionoAlarm; 

        //event - slowo kluczowe kompilatora,
        //do tego bedzie mozna podlaczyc metofde
        public event Action PodniesionoAlarm2;


    }

    


}


