﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Property_change_Binding
{
    public class TestViewModel : INotifyPropertyChanged
    {

        //okienko podlacza sie do danych,
        //okienko window1
        public TestViewModel()
        {
            DaneWejsciowe = "Dane z konstruktora";
        }

        public string DaneWejsciowe
        {
            get { return m_DaneWejsciowe; }
            set
            {

                if (m_DaneWejsciowe != value)
                {
                    m_DaneWejsciowe = value;
                    RaisePropertyChanged("DaneWejsciowe");
                }

            }
        }
        string m_DaneWejsciowe;

        private void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;//bo praca wielowatkowa
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));

        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

}
