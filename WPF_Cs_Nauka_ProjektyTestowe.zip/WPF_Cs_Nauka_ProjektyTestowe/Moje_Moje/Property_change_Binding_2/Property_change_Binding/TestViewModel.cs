﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace Property_change_Binding
{
    public class TestViewModel : INotifyPropertyChanged
    {

        //okienko podlacza sie do danych,
        //okienko window1
        public TestViewModel()
        {
            DaneWejsciowe = "5sss";
        }

        public string DaneWejsciowe
        {
            get { return m_DaneWejsciowe; }
            set
            {
                m_DaneWejsciowe = value;
                if(PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("DaneWejsciowe"));
            }
        }
        string m_DaneWejsciowe;

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }

}
