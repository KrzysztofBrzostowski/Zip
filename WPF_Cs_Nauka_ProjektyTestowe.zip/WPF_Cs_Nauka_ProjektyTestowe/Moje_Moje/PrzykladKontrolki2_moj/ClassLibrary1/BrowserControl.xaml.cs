﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFControls
{
    /// <summary>
    /// Interaction logic for BrowserControl.xaml
    /// </summary>
    public partial class BrowserControl : UserControl
    {
        public BrowserControl()
        {
            InitializeComponent();
           // Dane model = new Dane(); this.DataContext = model;
        }

        public static readonly DependencyProperty
            sciezkaMojaNazwaDepPropProperty =
            DependencyProperty.Register("sciezkaMojaNazwaDepProp",
                                                        typeof(string),
                                                        typeof(BrowserControl),
                                                        new PropertyMetadata("jakis_napis",
                                                            new PropertyChangedCallback( sciezkaMojaNazwaDepPropCallback), 
                                                            new CoerceValueCallback(sciezkaMojaNazwaDepPropCoerce)
                                                            )
                                                            );

        public string sciezkaMojaNazwaDepProp
        {
            get { return (string)GetValue(sciezkaMojaNazwaDepPropProperty); }
            set { SetValue(sciezkaMojaNazwaDepPropProperty, value); }
        }


        private static object sciezkaMojaNazwaDepPropCoerce(DependencyObject d, object baseValue)
        {

            return baseValue;
        }

        
        private static void sciezkaMojaNazwaDepPropCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            BrowserControl bc = (BrowserControl)d;
            bc.mojTextBlock.Text = e.NewValue.ToString();
        }

    }
}
