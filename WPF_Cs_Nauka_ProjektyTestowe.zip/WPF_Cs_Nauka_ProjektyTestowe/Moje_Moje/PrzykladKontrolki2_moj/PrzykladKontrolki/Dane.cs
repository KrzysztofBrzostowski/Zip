﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WpfApplication1
{
    class Dane : INotifyPropertyChanged
    {

        public Dane()
        {
            path = "przykladowa_sciezka";
        }

        private string m_path;
        public string path
        {
            get { return m_path; }
            set
            {
                m_path = value;

                var handler = PropertyChanged;
                if (handler != null)
                { handler(this, new PropertyChangedEventArgs("path")); }

            }
        }



        public event PropertyChangedEventHandler PropertyChanged;



    }
}
