PROGRAMOWANIE OBIEKTOWE

PRZYK�AD
OBIEKCIE_KARTY.WYPISZ_MI(COS_TAM)

KLASO_USTAWIAJACA_PARAMETRY.PODAJ_MI(COS_TAM)

KLASA_WYSYLAJACA_DO_PIPE.START()


///////////////////////////////////

Pomysly:

        private void CommandBinding_CanExecute_Rec(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }


///////////////////////////////////////////////////////////////////


SpectrumControl.xaml - fonty na spectrum


-----------------------------------------------

		DOPRECYZOWAC !!!

-------------------------------------------------

            // (x/y) w g�r�
            // (x+y-1)/y
            // 11/5 = 2.co� w g�r� to 3
            // (11+5-1)/5 = 17/5 = 3

            // (x/y) zaokr�glenie do najbli�ej
            // 

			
---------------------------------------------------

	//Engine.Channels[0].Freeze.Value = 1.0f;

	/* Jakby to rozpisa�, to b�dzie to samo co:
	 * DXTCD.DXTCD obiekt_dxtcd = Engine;
	 * Channels obiekt_channels = obiekt_dxtcd.Channels;
	 */

	/*

	// wersja pe�na
	private int i;
	public int I
	{ get { return i; } set { i=value;} }
	// wersja skr�cona
	public int I { get; set; }

	obiekt_klasy_tej.I=5;
	string napis = obiekt_klasy_tej.I.ToString();


	*/

	/*
	 * jeste�my w �rodku jakiej� funkcji\
	 * void funkcja()
	 * {
	 *   DXTCD zmienna;
	 *   zmienna.co�tamco�tam = 1.0f;
	 *   
	 *   GetDxtcd().co�tamco�tam = 1.0f;
	 * }
	 * 
	 * DXTCD GetDxtcd() { ... }
	 */

-----------------------------------

jak jest napisane tak:

public DXTCD.DXTCD Engine { get; set; }

to jest tzw. auto-implemented property.

Engine = abc; // przypisanie do w�a�ciwo�ci Engine - wywo�uje si� set
abc = Engine; // odczytanie z Engine - wywo�uje si� get
funkcja(Engine); // jak wy�ej

Tamten zapis to jest skr�t od jak gdyby� napisa� tak:

private DXTCD.DXTCD Engine_pole;
public DXTCD.DXTCD Engine {
	get { return Engine_pole; };
	set { Engine_pole = value; };
}
	 



///////////////////////////////////////////////////////////////////

class Class1
{
        public enum WhatHappened
        {
                ThingA,
                ThingB,
                Nothing
        }

        private delegate WhatHappened del();

        public static List<WhatHappened> DoStuff()
        {
                List<del> CheckValues = new List<del>();

                List<WhatHappened> returnValue = new List<WhatHappened> { };

                CheckValues.Add(delegate { return method1(); });
                CheckValues.Add(delegate { return method2(); });

                CheckValues.ForEach(x =>
                {
                        WhatHappened wh = x();
                        if (wh != WhatHappened.Nothing)
                                returnValue.Add(wh);
                });

                return returnValue;

        }

        private static WhatHappened method1()
        {
                return WhatHappened.Nothing;
        }

        private static WhatHappened method2()
        {
                return WhatHappened.ThingA;
        }

}


-------------------------------------------------

using System;

public class SamplesArray
{
    public static void Main()
    {
        // create a three element array of integers
        int[] intArray = new int[] {2, 3, 4};

        // set a delegate for the ShowSquares method
        Action<int> action = new Action<int>(ShowSquares);

        Array.ForEach(intArray, action);
    }

    private static void ShowSquares(int val)
    {
        Console.WriteLine("{0:d} squared = {1:d}", val, val*val);
    }
}




-----------------------------------------------------------------

public class CmdLineArgsExample {
	public static void Main(string [] args) {
	 
	foreach (string s in args) {
		System.Console.WriteLine(s);
		}
	}
}
---------------------------------------
   1. Dictionary<int, String> DictObj =   
   2.       new Dictionary<int, String>();  
   3.   
   4. DictObj.Add(1, "ABC");  
   5. DictObj.Add(2, "DEF");  
   6. DictObj.Add(3, "GHI");  
   7. DictObj.Add(4, "JKL");  
   8.   
   9. foreach (KeyValuePair<int,String> kvp in DictObj)  
  10. {  
  11.     int v1 = kvp.Key;  
  12.     String v2 = kvp.Value;  
  13.     Debug.WriteLine("Key: " + v1.ToString() +   
  14.          " Value: " + v2);  
  15. }  


   1. Dictionary<int,String>.KeyCollection keyCollection=  
   2.      DictObj.Keys;  
   3.   
   4. foreach (int key in keyCollection)  
   5. {  
   6.     Debug.WriteLine("Key: " + key.ToString());  
   7. }  
   8.   
   9. Dictionary<int,String>.ValueCollection valueCollection = DictObj.Values;  
  10.   
  11. foreach (String value in valueCollection)  
  12. {  
  13.      Debug.WriteLine("Value: " + value.ToString());  
  14. }  

----------------------------------------------------------------


//trivial example
List<string> strings = GetStrings();
foreach (string s in strings)
{
// some operation;
}

strings.ForEach(
delegate(string s)
{
// some operation
}
);

/////////////////////////////



long Sum(List<int> intList)
{
  long result = 0;
  intList.ForEach(delegate(int i) { result += i; });
  result result;
}

Or, the lambda expression equivalent:
long Sum(List<int> intList)
{
  long result = 0;
  intList.ForEach(i => result += i);
  return result;
}



////////////////////////////

   1. Iterate using a for-loop: for (int i = 0; i < List<int>.Count; i++)
   2. Iterate using a for-loop with no Count call: for (int i = 0; i < NUM_ITEMS; i++)
   3. Iterate using a foreach loop: foreach (int i in List<int>)
   4. Iterate using a List<int>.ForEach call: List<int>.ForEach(delegate(int i) { result += i; });



-------------------------------------------------------------------

using System.Collections.Generic;
using CommonTypes.Interfaces.EventBroker;

//Listeners.Values.ToString();
//List<IListener> a = new List<IListener>(); a.foreach


/*

foreach(var v in Listeners[type]) //v to elementy listy
{
v.
}
*/

namespace ScanerServices
{
    public class EventBroker : IEventBroker
    {
        public EventBroker()
        {
            Listeners = new Dictionary<EventType, List<IListener>>();            
        }

        private readonly Dictionary<EventType, List<IListener>> Listeners;
        public void RegisterFor(EventType type, IListener listener)
        {
            if (Listeners.ContainsKey(type) == false)
            { 
                Listeners.Add(type, new List<IListener>());
            }
            var listenersList = Listeners[type];
            if (listenersList.Contains(listener) == false)    
                listenersList.Add(listener);
        }

        public void FireEvent(EventType type,object data)
        { 
            if (Listeners.ContainsKey(type) == false)
                return;

            var listenersList = Listeners[type];
            listenersList.ForEach(l => l.NotifyMe(type, data));
        }

        public void UnregisterFrom(EventType type, IListener listener)
        {
            if (Listeners.ContainsKey(type) == false)
            {
                return;
            }
            var listenersList = Listeners[type];
            if (listenersList.Contains(listener))
                listenersList.Remove(listener);
        }

        public void UnregisterFromAll(IListener listener)
        {
            foreach (var eventType in Listeners.Keys)
            {
                if (Listeners[eventType].Contains(listener))
                    Listeners[eventType].Remove(listener);
            }            
        }
    }
}



------------------------------------------------------------------




-------------------------------------------------------

AvalonDock - Dock przenosny
-------------------------------------------------------
PROGRAMOWANIE OBIEKTOWE

PRZYK�AD
OBIEKCIE_KARTY.WYPISZ_MI(COS_TAM)

KLASO_USTAWIAJACA_PARAMETRY.PODAJ_MI(COS_TAM)

KLASA_WYSYLAJACA_DO_PIPE.START()
---------------------------------------------------------