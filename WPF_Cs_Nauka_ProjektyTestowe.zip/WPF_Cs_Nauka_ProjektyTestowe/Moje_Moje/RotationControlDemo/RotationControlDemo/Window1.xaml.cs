﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace RotationControlDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            // Create a Polyline.
            Polyline polyline1 = new Polyline();
            polyline1.Points.Add(new Point(25, 25));
            polyline1.Points.Add(new Point(0, 50));
            polyline1.Points.Add(new Point(25, 75));
            polyline1.Points.Add(new Point(50, 50));
            polyline1.Points.Add(new Point(25, 25));
            polyline1.Points.Add(new Point(25, 0));
            polyline1.Stroke = Brushes.Blue;
            polyline1.StrokeThickness = 10;

            // Create a RotateTransform to rotate
            // the Polyline 45 degrees about its
            // top-left corner.
            RotateTransform rotateTransform1 =
                new RotateTransform(90);
            polyline1.RenderTransform = rotateTransform1;


            RotateTransform rotateTransform2 =
                new RotateTransform(135);
            polyline1.RenderTransform = rotateTransform2;


            // Create a Canvas to contain the Polyline.
            //Canvas canvas1 = new Canvas();
            myGrid.Width = 200;
            myGrid.Height = 200;
            //Canvas.SetLeft(polyline1, 100);
            //Canvas.SetTop(polyline1, 50);
            myGrid.Children.Add(polyline1);
            //Thread.Sleep(1000);
            //canvas1.Children.Remove(polyline1);




        }
    }
}
