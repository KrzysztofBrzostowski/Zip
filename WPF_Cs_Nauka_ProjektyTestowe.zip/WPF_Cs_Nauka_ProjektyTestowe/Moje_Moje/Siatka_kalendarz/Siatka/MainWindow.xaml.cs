﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Siatka
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btZapisz_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(string.Format(
                "{0} {1}\nData urodzenia: {2}",
                txtImie.Text,
                txtNazwisko.Text,
                calDataUrodzenia.SelectedDate.Value.ToString("yyyy-MM-dd (ddd)")
                ));
        }
    }
}
