﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Sigletob
{
    class JednaIns
    {

        private static readonly JednaIns m_singl;
        public static JednaIns instancja
        {
            get { return m_singl; }
            

        }

        private JednaIns()
        {

        }

        static JednaIns()
        {
            m_singl = new JednaIns();
        }


        public void przywitaj_sie()
        {

            MessageBox.Show("Czesc!");
        }

    }
}
