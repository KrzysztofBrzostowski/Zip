﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ChangeFirstTextBlockText(object sender, RoutedEventArgs e)
        {
            this.MessageTextBlock.Text = "Message TextBlock's new text";
        }

        private void ChangeSecondTextBlockText(object sender, RoutedEventArgs e)
        {
            // get the second status bar item

            StatusBarItem item = (StatusBarItem)this.TestStatusBar.Items[2];

            // get the content textblock of the status bar item

            TextBlock textBlock = (TextBlock)item.Content;

            // change text

            textBlock.Text = "Second TextBlock's new text";
        }
    }
}
