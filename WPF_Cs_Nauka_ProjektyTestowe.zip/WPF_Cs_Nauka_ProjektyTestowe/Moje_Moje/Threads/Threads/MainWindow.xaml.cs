﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace Threads
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //delegate void mojTyp();

        private void metoda01()
        {
            //textBox1.Text = "cokolwiek";
            textBox1.Dispatcher.Invoke(new Action(() => { textBox1.Text = "cokolwiek"; }));
        }

        private void metoda02(object ob01)
        {
            //textBox1.Text = "cokolwiek";
            textBox1.Dispatcher.Invoke(new Action(() => { textBox1.Text = ob01.ToString(); }));
        }


        private void button1_Click(object sender, RoutedEventArgs e)
        {
           var watek = new Thread(new ThreadStart(metoda01));//tu sprawzic jescz eraz void () tyarget
           watek.Start();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
           var watek = new Thread( new ParameterizedThreadStart(metoda02));//tu sprawzic jescz eraz void () tyarget
           watek.Start("Ala bez kota");
       

        }



    }
}
