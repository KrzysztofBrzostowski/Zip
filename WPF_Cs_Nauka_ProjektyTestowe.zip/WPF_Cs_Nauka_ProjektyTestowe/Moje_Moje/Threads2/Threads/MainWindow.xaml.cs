﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.IO;

namespace Threads
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void metoda01()
        {
            //textBox1.Text = "cokolwiek";
            textBox1.Dispatcher.Invoke(new Action(() => { textBox1.Text = "cokolwiek"; }));
        }

        private void metoda02(object ob01)
        {
            
            textBox1.Dispatcher.Invoke(new Action(() => {

                using (StreamReader reader = new StreamReader((string)ob01))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        textBox1.Text += line;
                    }
                }
            
            }));
            
        }

        Thread watek;
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            /*
            var watek = new Thread(new ThreadStart(metoda01));//tu sprawzic jescz eraz void () tyarget
            watek.Start(); 
            */    

                //var watek = new Thread(new ThreadStart(new Action(() => { textBox1.Text = "Jescze inny sposób"; })));
                //watek.Start();

            watek = new Thread(new ThreadStart(new Action(() => { textBox1.Dispatcher.Invoke(new Action(() => { textBox1.Text = "Jescze inny sposób"; })); })));

            watek.Start();
            //watek.Join();
        }


        private void button2_Click(object sender, RoutedEventArgs e)
        {

            Microsoft.Win32.OpenFileDialog f = new Microsoft.Win32.OpenFileDialog();
            if (f.ShowDialog().Value)
            {
                //var watek = new Thread(new ParameterizedThreadStart(metoda02));

                //var watek = new Thread(new ParameterizedThreadStart(new Action<object>(ob => 
                //{
                //    textBox1.Dispatcher.Invoke(new Action(() =>
                //    {
                //        using (StreamReader reader = new StreamReader((string)ob))
                //        {
                //            string line;
                //            while ((line = reader.ReadLine()) != null)
                //            {
                //                textBox1.Text += line;
                //            }

                //        }
                //    }
                //    )//new Action(
                //    );//.Invoke
                //}//poczatek lambda 
                //))
                //);



                var watek = new Thread(new ParameterizedThreadStart( /*new Action<object>(*/ ob =>
                {
                    textBox1.Dispatcher.Invoke(new Action(() =>
                    {
                        using (StreamReader reader = new StreamReader((string)ob))
                        {
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {
                                textBox1.Text += line;
                            }

                        }
                    }
                    )//new Action(
                    );//.Invoke
                }//poczatek lambda 

                //)//new Action<object>

                )//new Parameterized...

                ); //new Thread



                watek.Start(f.FileName);


            }
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
           // watek.Join();
        }


    }
}
