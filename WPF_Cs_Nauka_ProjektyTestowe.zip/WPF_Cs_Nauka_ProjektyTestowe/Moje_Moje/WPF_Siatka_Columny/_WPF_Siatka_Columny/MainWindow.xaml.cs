﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WPF_Siatka_Columny
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public ObservableCollection<Osoba> Osoby { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            DataContext = this;
            Osoby = new ObservableCollection<Osoba>();

            Osoby.Add(new Osoba { Imie = "Krzysztof", DataUrodzenia = new DateTime(1980, 04, 03) });
            Osoby.Add(new Osoba { Imie = "JAn", DataUrodzenia = new DateTime(1981, 05, 07) });


        }
    }
}
