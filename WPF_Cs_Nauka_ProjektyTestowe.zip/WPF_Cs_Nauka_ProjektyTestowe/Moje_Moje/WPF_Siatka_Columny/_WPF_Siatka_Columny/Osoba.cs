﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPF_Siatka_Columny
{
    public class Osoba
    {
        public string Imie { get; set; }
        public DateTime DataUrodzenia { get; set; }
    }
}
