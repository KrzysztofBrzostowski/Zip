﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace WiazanieDanych
{
    class Faktura : /*KlasaBazowa,*/ INotifyPropertyChanged
    {
        public Faktura()
        {
            NumerFaktury = "2011/03/04";
            DataWystawienia = DateTime.Now;
            Pozycje = new ObservableCollection<PozycjaFaktury>();
        }

        public string NazwaKlienta { get; set; }
        public DateTime DataWystawienia { get; set; }
        public string NumerFaktury { get; set; }

        public ObservableCollection<PozycjaFaktury> Pozycje { get; set; }
        
        public void WysliInfoOWartosciFaktury()
        {
            WysliPowiadomienie("WartoscFaktury");
        }

        public decimal WartoscFaktury 
        {
            get
            {
                decimal wartoscFaktury = 0;
                foreach (var pozycja in Pozycje)
                {
                    wartoscFaktury += pozycja.Wartosc;
                }

                return wartoscFaktury;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void WysliPowiadomienie(string nazwaWlasciwosci)
        {
            if (null != PropertyChanged)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(nazwaWlasciwosci));
            }
        }
    }
}
