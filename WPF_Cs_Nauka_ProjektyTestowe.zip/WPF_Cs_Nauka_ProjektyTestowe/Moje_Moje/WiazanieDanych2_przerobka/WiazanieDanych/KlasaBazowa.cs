﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WiazanieDanych
{
    class _KlasaBazowa : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void WysliPowiadomienie(string nazwaWlasciwosci)
        {
            if (null != PropertyChanged)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(nazwaWlasciwosci));
            }
        }
    }
}
