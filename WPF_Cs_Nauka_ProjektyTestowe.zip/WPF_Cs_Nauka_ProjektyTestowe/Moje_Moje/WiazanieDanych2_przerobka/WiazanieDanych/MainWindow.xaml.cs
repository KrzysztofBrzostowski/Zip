﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WiazanieDanych
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PozycjaFaktury _pozycjaFaktury = new PozycjaFaktury(null);

        public MainWindow()
        {
            InitializeComponent();

            this.DataContext = _pozycjaFaktury;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(
                string.Format("Cena = {0}\nIlosc = {1}\nWartosc = {2}",
                        _pozycjaFaktury.Cena,
                        _pozycjaFaktury.Ilosc,
                        _pozycjaFaktury.Wartosc));
        }
    }
}
