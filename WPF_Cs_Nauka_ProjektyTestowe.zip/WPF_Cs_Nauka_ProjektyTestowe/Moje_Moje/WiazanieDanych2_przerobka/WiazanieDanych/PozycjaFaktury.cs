﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;


using System.ComponentModel.DataAnnotations;

namespace WiazanieDanych
{
    class PozycjaFaktury :  INotifyPropertyChanged
    {

        Faktura _faktura;

        public PozycjaFaktury(Faktura faktura)
        {
            _faktura = faktura;
        }

        //[Browsable(false)] //Forms
        //[Display(AutoGenerateField=false)]
        public string NazwaProduktu { get; set; }

        private int ilosc;
        public int Ilosc
        {
            get { return ilosc; }
            set { ilosc = value; WysliPowiadomienie("Ilosc"); WysliPowiadomienie("Wartosc"); _faktura.WysliInfoOWartosciFaktury(); }
        }

        private decimal cena;
        public decimal Cena
        {
            get { return cena; }
            set { 
                cena = value; 
                WysliPowiadomienie("Cena"); 
                WysliPowiadomienie("Wartosc"); 
                _faktura.WysliInfoOWartosciFaktury(); }
        }

        public decimal Wartosc 
        {
            get
            {
                return Ilosc * Cena;
            }                 
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void WysliPowiadomienie(string nazwaWlasciwosci)
        {
            if (null != PropertyChanged)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(nazwaWlasciwosci));
            }
        }

    }
}
