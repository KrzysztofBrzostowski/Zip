﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WiazanieDanych
{
    /// <summary>
    /// Interaction logic for WidokFaktury.xaml
    /// </summary>
    public partial class WidokFaktury : Window
    {
        private Faktura _faktura = new Faktura();

        public WidokFaktury()
        {
            InitializeComponent();
            this.DataContext = _faktura;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            _faktura.Pozycje.Add(
                new PozycjaFaktury(_faktura) { Cena = 0, Ilosc = 1, NazwaProduktu = "N/A" });
        }

      
    }
}
