﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WiazanieDanychNiestandardowych
{
    /// <summary>
    /// Interaction logic for EdycjaProduktu.xaml
    /// </summary>
    public partial class EdycjaProduktu : Window
    {
        Produkt produktDoEdycji = null;
        Binding produktBinding_Nazwa = null;
        Binding produktBinding_Cena = null;

        public EdycjaProduktu()
        {
            InitializeComponent();
        }

        public EdycjaProduktu(Produkt produkt)
            :this()
        {
            produktDoEdycji = produkt;

            this.DataContext = produktDoEdycji;

            produktBinding_Nazwa = new Binding("Nazwa");
            produktBinding_Nazwa.NotifyOnValidationError = true;
            produktBinding_Nazwa.ValidatesOnExceptions = true;
            txtNazwa.SetBinding(TextBox.TextProperty, produktBinding_Nazwa);



            produktBinding_Cena = new Binding("Cena");

            //powiadom o bledach
            produktBinding_Cena.NotifyOnValidationError = true;

            //produktBinding_Cena.ValidatesOnExceptions = true;
            produktBinding_Cena.ValidatesOnDataErrors = true;

            txtCena.SetBinding(TextBox.TextProperty, produktBinding_Cena);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {            
            var listaBledow = Validation.GetErrors(txtCena);
            if (listaBledow.Count > 0)
            {
                //mamy jakies bledy walidacji obiektu Produkt
                foreach (var blad in listaBledow)
                {
                    MessageBox.Show(blad.ErrorContent.ToString());
                }
            }
            else
            {
                // wszsytko jest ok
                // zamykamy okenko
                this.DialogResult = true;
                this.Close();
            }
        }
    }
}
