﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace WiazanieDanychNiestandardowych
{
    class GeneratorPrzykladowychDanych
    {
        public static ObservableCollection<Produkt> PobierzProdukty()
        {
            var lista = new ObservableCollection<Produkt>();
            for (int i = 0; i < 10; i++)
            {
                lista.Add(new Produkt { Nazwa = "P " + i, Cena = 1.25M * i });
            }

            lista[5].Obraz = @"C:\Users\Public\Pictures\Sample Pictures\Hortensje.jpg";

            lista[1].Obraz = @"C:\Users\Public\Pictures\Sample Pictures\Koala.jpg";

            return lista;
        }
    }
}
