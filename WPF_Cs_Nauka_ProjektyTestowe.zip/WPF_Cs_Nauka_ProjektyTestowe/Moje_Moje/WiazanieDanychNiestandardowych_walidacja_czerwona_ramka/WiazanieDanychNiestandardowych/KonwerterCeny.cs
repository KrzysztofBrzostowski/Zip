﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows;

namespace WiazanieDanychNiestandardowych
{
    class KonwerterCeny : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value.ToString().PadRight(10, '0');
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //if (value == "jeden")
            /*
            if (value.ToString().Equals("jeden", StringComparison.InvariantCultureIgnoreCase))
            {
                return 1;
            }
            */

            decimal d;
            if (!decimal.TryParse(value.ToString(), out d))
            {
                MessageBox.Show("Bledna wartosc");
                return 0;
            }

            return value;
        }
    }
}
