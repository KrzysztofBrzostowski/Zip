﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WiazanieDanychNiestandardowych
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //KonwerterCeny k = new KonwerterCeny();

        public MainWindow()
        {
            InitializeComponent();
            //((Binding)col2.Binding).Converter = k;

            // podpinamy kolekcje produktow
            dataGrid1.ItemsSource = GeneratorPrzykladowychDanych.PobierzProdukty();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog f = new Microsoft.Win32.OpenFileDialog();
            if (f.ShowDialog().Value)
            {
                ((Produkt)dataGrid1.SelectedItem).Obraz = f.FileName;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Produkt zaznaczonyProdukt = dataGrid1.SelectedItem as Produkt;
            if (null != zaznaczonyProdukt)
            {
                EdycjaProduktu okienkoEdycjiProduktu = new EdycjaProduktu(zaznaczonyProdukt);
                okienkoEdycjiProduktu.ShowDialog();
            }
        }
    }
}
