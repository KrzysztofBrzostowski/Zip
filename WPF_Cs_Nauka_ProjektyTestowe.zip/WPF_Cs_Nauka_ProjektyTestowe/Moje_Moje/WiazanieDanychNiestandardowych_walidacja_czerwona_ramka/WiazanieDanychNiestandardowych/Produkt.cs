﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace WiazanieDanychNiestandardowych
{
    //walidacja danych
    public class Produkt : IDataErrorInfo
    {
        public string Obraz { get; set; }

        private string m_Nazwa;

        public string Nazwa
        {
            get { return m_Nazwa; }
            set {
                if (value.Length > 5) throw new ArgumentException("za dluga nazwa");
                m_Nazwa = value; }
        }
        

        private decimal cena;
        public decimal Cena
        {
            get { return cena; }
            set 
            {
                if (value < 0)
                {
                    //throw new ApplicationException("Zbyt niska cena");
                }

                cena = value;
            }
        }


        public string Error
        {
            get { return ""; }
        }

        public string this[string columnName]
        {
            get 
            {
                switch (columnName)
                {
                    case "Cena":
                        if (Cena > 100)
                        {
                            return "Za wysoka cena";
                        }
                        break;
                }

                return "";
            }
        }
    }
}
