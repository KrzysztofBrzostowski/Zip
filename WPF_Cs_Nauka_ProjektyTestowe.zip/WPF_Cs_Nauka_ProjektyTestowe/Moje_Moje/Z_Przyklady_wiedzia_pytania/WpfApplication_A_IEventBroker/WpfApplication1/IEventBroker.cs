﻿namespace WpfApplication1
{
    public enum EventType
    {
        ZmianaNazwyPliku
    }

    public interface IListener
    {
        void NotifyMe(EventType type, object data);
    }

    public interface IEventBroker
    {
        void RegisterFor(EventType type, IListener listener);
        void UnregisterFrom(EventType type, IListener listener);
        void UnregisterFromAll(IListener listener);
        void FireEvent(EventType type, object data);
    }
}
