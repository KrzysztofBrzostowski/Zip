﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //////// Przykład na właściwość

            //Klasa1 obiekt = new Klasa1();

            // 1
            //obiekt.Pole = 123;
            //int wartosc = obiekt.Pole;
            //MessageBox.Show(wartosc.ToString());

            // 2
            //obiekt.SetPrywatnePole(123);
            //int wartosc = obiekt.GetPrywatnePole();
            //MessageBox.Show(wartosc.ToString());

            // 3
            //obiekt.Wlasciwosc = 123;
            //int wartosc = obiekt.Wlasciwosc;
            //MessageBox.Show(wartosc.ToString());

            /* Właściwość - używasz jak pola, działa jak metody get i set. */


            //////// Przykład na binding

            // Stworzenie obiektów
            IEventBroker event_broker = new EventBroker();
            Menu menu = new Menu(event_broker);
            KlasaPosrednia obiekt_posredni = new KlasaPosrednia();
            KlasaDocelowa obiekt_docelowy = new KlasaDocelowa();

            // Łączenie obiektów

            // 1. Menu do obiekt_posredni za pomocą EventBroker
            event_broker.RegisterFor(EventType.ZmianaNazwyPliku, obiekt_posredni);

            // 2. obiekt_posredni do obiekt_docelowy za pomocą Bindingu
            Binding b = new Binding("NazwaPliku");
            b.Mode = BindingMode.OneWayToSource;
            b.Source = obiekt_docelowy;
            BindingOperations.SetBinding(obiekt_posredni, KlasaPosrednia.NazwaPlikuProperty, b);

            // Kod właściwy
            menu.wywolaj_polecenie(@"Plik1.txt");

            // Zakonczenie - rozłączenie obiektów
            event_broker.UnregisterFrom(EventType.ZmianaNazwyPliku, obiekt_posredni);
        }
    }

    class Klasa1
    {
        // 1 - Publiczne pole
        public int Pole;

        // 2 - Pole prywatne, metody dostępowe (getter i setter)
        private int PrywatnePole;
        public int GetPrywatnePole() { return PrywatnePole; }
        public void SetPrywatnePole(int wartosc) { PrywatnePole = wartosc; }

        // 3 - właściwość
        private int PrywatnePole2;
        public int Wlasciwosc
        {
            get { return PrywatnePole2; }
            set { PrywatnePole2 = value; }
        }
    }

    class Menu
    {
        private IEventBroker event_broker;

        public Menu(IEventBroker event_broker_parameter)
        {
            this.event_broker = event_broker_parameter;
        }

        public void wywolaj_polecenie(string nazwa_pliku)
        {
            event_broker.FireEvent(EventType.ZmianaNazwyPliku, nazwa_pliku);
        }
    }

    class KlasaPosrednia : DependencyObject, IListener
    {
        public static readonly DependencyProperty NazwaPlikuProperty = 
            DependencyProperty.Register("NazwaPliku", typeof(string), typeof(KlasaPosrednia));

        public string NazwaPliku
        {
            get { return (string)GetValue(NazwaPlikuProperty); }
            set { SetValue(NazwaPlikuProperty, value); }
        }

        public void NotifyMe(EventType type, object data)
        {
            string nazwa_pliku = (string)data;
            this.NazwaPliku = nazwa_pliku;
        }
    }

    class KlasaDocelowa
    {
        private string NazwaPliku_Pole;

        public string NazwaPliku
        {
            get { return NazwaPliku_Pole; }
            set {
                NazwaPliku_Pole = value;
                MessageBox.Show(string.Format("Wywołało się KlasaDocelowa.NazwaPliku.set dla value=\"{0}\"", value));
            }
        }
    }
}
