﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Xml_serialization
{
    class NaszaKlasa : IXmlSerializable
    {
        public int Liczba;
        public string Lancuch;

        #region IXmlSerializable Members

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            throw new NotImplementedException();
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");

            ReadWindowProperties(reader);
        }

        private void ReadWindowProperties(System.Xml.XmlReader reader)
        {
            while (reader.Read())
            {
                if (reader.LocalName == "Obiekt" && reader.IsStartElement())
                {
                    ReadProperties(reader);
                }
            }
        }

        private void ReadProperties(System.Xml.XmlReader reader)
        {
            while (reader.Read())
            {
                if (reader.NodeType == System.Xml.XmlNodeType.EndElement) break;
                if (!reader.IsStartElement()) continue;
                
                var key = reader.LocalName;
                var value = reader.ReadElementContentAsString();

                if (key == "Liczba")
                    this.Liczba = int.Parse(value);
                else if (key == "Lancuch")
                    this.Lancuch = value;
            }
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
