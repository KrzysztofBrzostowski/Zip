﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Zdarzenia_Publisher_Subscriber
{
    class Subscriber
    {

        public Subscriber()
        {
            Console.Write("Za chwile nastapi podpiecie metody do eventu."); Console.ReadLine();
            ProgramPublisher.proc_zdarzenie += new EventHandler(ProgramPublisher_proc_zdarzenie);

        }

        void ProgramPublisher_proc_zdarzenie(object sender, EventArgs e)
        {
            Console.Write("Uruchomiono procedure obslugi zdarzenia!"); Console.ReadLine();
        }

        //manipulator.HID_ENC_EventHandler += new EventHandler<MyEventArgs>(Handle_HID_ENC);
        //void Handle_HID_SWT(object sender, MyEventArgs e) { int nr_urzadzenia = ((SWT)e.urzadzenie).nr_urzadzenia; }

    }

    class ProgramPublisher
    {
        //public event EventHandler<MyEventArgs> HID_ENC_EventHandler;

        private static EventHandler proc_zdarzenie_priv;

        public static event EventHandler proc_zdarzenie
        {
            add
            {
                proc_zdarzenie_priv += value;
                Console.Write("Podpieto proceure do eventu."); Console.ReadLine();
            }
            remove
            {
                proc_zdarzenie_priv -= value;
            }
        }



        static void Main(string[] args)
        {
            //Ctrl kd
            // HID_ENC_EventHandler(this, new MyEventArgs() { urzadzenie = tab_ENC[dev_no] });

            Subscriber scrib = new Subscriber();
            Console.Write(" Nacisnij e aby uruchomic event: ");
            string wynik = Console.ReadLine();

            if (wynik.Equals("e"))
            {
                if (proc_zdarzenie_priv != null)
                {
                    proc_zdarzenie_priv(new object(), new EventArgs() { });



                    Console.Write("Koniec"); Console.ReadLine();

                }

            }

        }




    }




}
