class Zwierze {
	public void jedz() { ... }
};

class Ryba : Zwierze {
	public void plywaj() { ... }
};

class Ssak : Zwierze {
	public void ssaj() { ... }
};

interface IGryzacy {
	public void gryz();
};

class Pies : Ssak, IGryzacy {
	public void szczekaj();
	public void gryz() { ... }
};

class Kot : Ssak {
	public void miaucz();
};

class Szczupak : Ryba {
	public void gotuj_sie();
};

class Pirania : Ryba, IGryzacy {
	public void gryz() { ... }
};

class Program
{
	static void main(String[] args)
	{
		Pies azor = new Pies();
		Kot mruczus = new Kot();
		mruczus.miaucz();
		mruczus.ssaj();
		mruczus.jedz();
	}
}
//===========================================
/*
	"jan kowalski" -> 502784589
	"karol wi�niewski" -> 513545888
	
	Dictionary<string, int> ksiazka_telefoniczna;
	
	ksiazka_telefoniczna.add("jan kowalski", 502784589);
	
	
*/