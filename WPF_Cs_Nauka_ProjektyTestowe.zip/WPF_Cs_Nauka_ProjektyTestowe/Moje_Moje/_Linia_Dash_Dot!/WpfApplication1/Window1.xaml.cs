﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            Line line = new Line();
            line.X1 = 0;
            line.Y1 = 100;
            line.X2 = 300;
            line.Y2 = 100;
            line.StrokeThickness = 4;
            line.Stroke = Brushes.Blue;

            DoubleCollection dc = new DoubleCollection();
            dc.Add(8d);
            dc.Add(4d);

            line.StrokeDashArray = dc;
            mojGrid.Children.Add(line);


        }
    }
}
