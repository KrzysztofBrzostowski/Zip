// Math.h

#pragma once

extern "C" __declspec(dllexport) float Add(float a, float b);

