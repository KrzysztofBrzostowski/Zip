﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        // Read in list of English words.
        var lines = new List<string>(File.ReadAllLines("enable1.txt"));

        // This dictionary contains all strings. [172820 keys]
        var dictionary1 = lines.ToDictionary(s => s, s => true);

        foreach (string str in dictionary1.Keys)
        {
            Console.WriteLine("{0}", str);

        }


        // Shrink the List to half its size.
        lines = lines.Take(lines.Count / 2).ToList();

        // This dictionary contains half. [86410 keys]
        var dictionary2 = lines.ToDictionary(s => s, s => true);

        const int m = 100;
        Stopwatch s1 = Stopwatch.StartNew();
        for (int i = 0; i < m; i++)
        {
            foreach (string s in lines)
            {
                if (!dictionary1.ContainsKey(s))
                {
                    throw new Exception();
                }
            }
        }
        s1.Stop();
        Stopwatch s2 = Stopwatch.StartNew();
        for (int i = 0; i < m; i++)
        {
            foreach (string s in lines)
            {
                if (!dictionary2.ContainsKey(s))
                {
                    throw new Exception();
                }
            }
        }
        s2.Stop();
        Console.WriteLine("{0},{1}", s1.ElapsedMilliseconds, s2.ElapsedMilliseconds);
        Console.Read();
    }
}


