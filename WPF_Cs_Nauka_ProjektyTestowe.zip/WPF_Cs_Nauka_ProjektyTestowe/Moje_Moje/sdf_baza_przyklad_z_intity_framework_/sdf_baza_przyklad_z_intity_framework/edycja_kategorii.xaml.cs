﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace sdf_baza_przyklad_z_intity_framework
{
    /// <summary>
    /// Interaction logic for edycja_kategorii.xaml
    /// </summary>
    public partial class edycja_kategorii : Window
    {

        private przykladowa_baza_lokalnaEntities m_db; //dotep do  bazy przez entity framework
        //tabela -> klasa
        //baza danych  -> przykladowa_baza_lokalnaEntities

        public edycja_kategorii()
        {
            InitializeComponent();
            m_db = new przykladowa_baza_lokalnaEntities();
            m_db.SavingChanges += new EventHandler(m_db_SavingChanges);


            dataGrid1.ItemsSource = m_db.Kategorie;

        }

        void m_db_SavingChanges(object sender, EventArgs e)
        {
            //dataGrid1.ItemsSource = null;
            //dataGrid1.ItemsSource = m_db.Kategorie;

            //ponieważ DataGrid trzyma kopie wierszy a nie referencje do kolekcji Entity
            this.dataGrid1.Items.Refresh(); //http://msdn.microsoft.com/en-us/data/jj574514.aspx

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //kategoria -> jeden wiersz
            Kategoria kat = new Kategoria();
            kat.kategoria_id = Guid.NewGuid(); //
            kat.nazwa = "kategia testowa";
            m_db.Kategorie.AddObject(kat);
            //m_db.Produkty.ToList().

            m_db.SaveChanges();

            

            dataGrid1.ItemsSource = null;

            this.dataGrid1.Items.Refresh(); //http://msdn.microsoft.com/en-us/data/jj574514.aspx
           
            dataGrid1.ItemsSource = m_db.Kategorie;


            //ponieważ DataGrid trzyma kopie wierszy a nie referencje do kolekcji Entity
            this.dataGrid1.Items.Refresh(); //http://msdn.microsoft.com/en-us/data/jj574514.aspx
           
            
        }

        private void bDelete_Click(object sender, RoutedEventArgs e)
        {
            Kategoria kat = (dataGrid1.SelectedItem as Kategoria);

            if (kat != null)
            {
                m_db.Kategorie.DeleteObject(kat);

                m_db.SaveChanges();
            }

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            int i = m_db.Kategorie.Count();

            MessageBox.Show(i.ToString());
        }
    }
}
