﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for edycja_kategorii.xaml
    /// </summary>
    public partial class edycja_kategorii : Window
    {
        private Database1Entities m_db = new Database1Entities();


        public edycja_kategorii()
        {
            InitializeComponent();
            m_db = new Database1Entities();
            m_db.SavingChanges +=new EventHandler(m_db_SavingChanges);
        }

        void m_db_SavingChanges(object sender, EventArgs e)
        {
            dataGrid1.ItemsSource = null;
            dataGrid1.ItemsSource = m_db.kategorie;
        
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            kategoria kat = new kategoria();
            kat.kat_id = Guid.NewGuid();
            kat.nazwa = "kategoria testowa";
            m_db.kategorie.AddObject(kat);
            m_db.SaveChanges();

        }
    }
}
