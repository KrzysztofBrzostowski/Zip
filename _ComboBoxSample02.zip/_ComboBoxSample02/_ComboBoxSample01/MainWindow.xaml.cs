﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ComboBoxSample01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
            dict = new Dictionary<DateTime, string>(); 

            dict.Add(new DateTime(2012, 05, 24), "Dzis");
            dict.Add(new DateTime(1980, 04, 03), "KB");
            dict.Add(new DateTime(2000, 01, 01), "inni");

            DataContext = this;
            InitializeComponent();

        }

        public Dictionary<DateTime, string> dict { get; set; }
        public object wybranaPozycja;

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(myCombo.SelectedIndex.ToString());
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(myCombo.SelectedItem.ToString());
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(myCombo.SelectedValue.ToString());
        }

    }
}
