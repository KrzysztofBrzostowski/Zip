﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ComboBoxSample01.Przyklad2
{
    class ViewModel
    {
        public ViewModel()
        {


            //dict = new Dictionary<string, int>();
            //dict.Add("1", 1);
            //dict.Add("2", 2);
            //dict.Add("3", 3);

        }

        private int m_Value2=30;

        public int Value2
        {
            get { return m_Value2; }
            set { m_Value2 = value; }
        }
        
        public int Value { get; set; }

        public Dictionary<string, int> dict
        {
            get
            {
                return new Dictionary<string, int>() { { "1s", 1 }, { "2s", 2 }, { "3s", 3 } };
            }
        }
    }
}
