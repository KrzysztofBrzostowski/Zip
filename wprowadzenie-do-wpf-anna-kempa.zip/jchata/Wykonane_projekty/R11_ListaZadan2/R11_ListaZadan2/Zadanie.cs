﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R11_ListaZadan2
{
    class Zadanie
    {
        public string Nazwa { get; set; }
        public string Opis { get; set; }
        public int Priorytet { get; set; }
    }
}
