﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R12_Walidacja_ValidationRules
{
    class Towar
    {
        public string Nazwa { get; set; }
        public double Cena { get; set; }
    }
}
