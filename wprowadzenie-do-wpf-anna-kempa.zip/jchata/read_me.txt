Kody program�w wykorzystanych w podr�czniku Kempa A. "Wprowadzenie do WPF. 
Tworzenie aplikacji WPF przy u�yciu XAML i C#", Helion, Gliwice 2017
******************************************************************************

==============================================================================
Jak korzysta� z kod�w
==============================================================================

Kody udost�pnione s� w dw�ch wersjach:
--------------------------------------
- w folderze Kody_do_nauki - znajduj� si� kody przeznaczone do nauki programowania w WPF 
  wed�ug obja�nie� podanych w tre�ci podr�cznika. 
  Zaleca si� korzystanie przede wszystkim z tych kod�w podczas nauki.
  W folderze tym znajduje si� tak�e folder z plikami z grafik� wykorzystanymi w programach. 
  Mo�na je wykorzysta� podczas tworzenia w�asnych wersji program�w (lub dowolne inne).

- w folderze Wykonane_projekty - znajduj� si� gotowe projekty program�w. 
  Nazwy projekt�w zaczynaj� si� od symbolu rozdzia�u (np. R2 - to rozdzia� 2., R3 to rozdzia� 3. itd.).
  Mo�na skorzysta� z tych projekt�w w przypadku wi�kszych trudno�ci z uruchomieniem swojej wersji programu.
  W�r�d gotowych projekt�w nie ma program�w dla zada� do samodzielnego wykonania, dla kt�rych umieszczono
  jedynie wskaz�wki (kody s� dost�pne w folderze Kody_do_nauki).
  [Wskaz�wka dla os�b pocz�tkuj�cych: Uruchomienie projektu - gotowy projekt mo�emy uruchomi� np. w opcji 
  File/Open/Project lub ze strony pocz�tkowej poprzez link Open Project/Solution wskazuj�c folder 
  z projektem, a nast�pnie plik z rozszerzeniem sln (np. R2_Przywitanie.sln). Kody programu projektu 
  mo�na przejrze� wybieraj�c nazwy plik�w w oknie Solution Explorer].
 

==============================================================================
Informacje o wersji Visual Studio
==============================================================================
Informacje o wersji Visual Studio znajduj� si� w folderze Dodatkowe_informacje
